package tools.jackson.databind.exc;

import java.io.Serial;

import tools.jackson.core.JsonParser;

import tools.jackson.databind.BeanProperty;

@SuppressWarnings("deprecation") // extends deprecated MissingInjectableValueExcepion for backward compatibility
public class MissingInjectableValueException
    extends MissingInjectableValueExcepion
{
    @Serial
    private static final long serialVersionUID = 3L;

    protected MissingInjectableValueException(JsonParser p, String msg,
            Object valueId, BeanProperty forProperty, Object beanInstance)
    {
        super(p, msg, valueId, forProperty, beanInstance);
    }

    public static MissingInjectableValueException from(JsonParser p, String msg,
            Object valueId, BeanProperty forProperty, Object beanInstance)
    {
        return new MissingInjectableValueException(p, msg, valueId, forProperty, beanInstance);
    }

    @Override
    public Object getValueId() { return super.getValueId(); }
    @Override
    public BeanProperty getForProperty() { return super.getForProperty(); }
    @Override
    public Object getBeanInstance() { return super.getBeanInstance(); }
}
