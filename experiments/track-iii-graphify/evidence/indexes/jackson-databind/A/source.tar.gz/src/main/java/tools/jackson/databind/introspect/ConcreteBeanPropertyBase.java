package tools.jackson.databind.introspect;

import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import tools.jackson.databind.*;
import tools.jackson.databind.cfg.MapperConfig;

/**
 * Intermediate {@link BeanProperty} class shared by concrete readable- and
 * writable property implementations for sharing common functionality.
 */
public abstract class ConcreteBeanPropertyBase
    implements BeanProperty
{
    /**
     * Additional information about property
     */
    protected final PropertyMetadata _metadata;

    protected transient List<PropertyName> _aliases;

    protected ConcreteBeanPropertyBase(PropertyMetadata md) {
        _metadata = (md == null) ? PropertyMetadata.STD_REQUIRED_OR_OPTIONAL : md;
    }

    protected ConcreteBeanPropertyBase(ConcreteBeanPropertyBase src) {
        _metadata = src._metadata;
    }

    @Override
    public boolean isRequired() { return _metadata.isRequired(); }

    @Override
    public PropertyMetadata getMetadata() { return _metadata; }

    @Override
    public boolean isVirtual() { return false; }

    @Override
    public JsonFormat.Value findFormatOverrides(MapperConfig<?> config) {
        AnnotatedMember member = getMember();
        if (member != null) {
            return config.getAnnotationIntrospector().findFormat(config, member);
        }
        return null;
    }

    @Override
    public JsonFormat.Value findPropertyFormat(MapperConfig<?> config, Class<?> baseType)
    {
        JsonFormat.Value format = config.getDefaultPropertyFormat(baseType);
        JsonFormat.Value overrides = findFormatOverrides(config);

        return (overrides == null) ? format : format.withOverrides(overrides);
    }

    // Left abstract at this level: only implemented properly on serialization side
    //@Override
    //public abstract JsonInclude.Value findPropertyInclusion(MapperConfig<?> config, Class<?> baseType);

    @Override
    public List<PropertyName> findAliases(MapperConfig<?> config)
    {
        List<PropertyName> aliases = _aliases;
        if (aliases == null) {
            final AnnotatedMember member = getMember();
            if (member != null) {
                aliases = config.getAnnotationIntrospector().findPropertyAliases(config, member);
            }
            if (aliases == null) {
                aliases = Collections.emptyList();
            }
            _aliases = aliases;
        }
        return aliases;
    }
}
