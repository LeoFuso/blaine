package tools.jackson.databind.deser.impl;

import java.util.*;

import tools.jackson.core.*;

import tools.jackson.databind.*;
import tools.jackson.databind.deser.SettableBeanProperty;
import tools.jackson.databind.deser.bean.BeanPropertyMap;
import tools.jackson.databind.deser.bean.PropertyBasedCreator;
import tools.jackson.databind.deser.bean.PropertyValueBuffer;
import tools.jackson.databind.jsontype.TypeDeserializer;
import tools.jackson.databind.jsontype.impl.TypeDeserializerBase;
import tools.jackson.databind.util.TokenBuffer;
import tools.jackson.databind.util.TokenBufferReadContext;

/**
 * Helper class that is used to flatten JSON structure when using
 * "external type id" (see {@link com.fasterxml.jackson.annotation.JsonTypeInfo.As#EXTERNAL_PROPERTY}).
 * This is needed to store temporary state and buffer tokens, as the structure is
 * rearranged a bit so that actual type deserializer can resolve type and
 * finalize deserialization.
 */
public class ExternalTypeHandler
{
    private final JavaType _beanType;

    private final ExtTypedProperty[] _properties;

    /**
     * Mapping from external property ids to one or more indexes;
     * in most cases single index as <code>Integer</code>, but
     * occasionally same name maps to multiple ones: if so,
     * <code>List&lt;Integer&gt;</code>.
     */
    private final Map<String, Object> _nameToPropertyIndex;

    private final String[] _typeIds;
    private final TokenBuffer[] _tokens;

    protected ExternalTypeHandler(JavaType beanType,
            ExtTypedProperty[] properties,
            Map<String, Object> nameToPropertyIndex,
            String[] typeIds, TokenBuffer[] tokens)
    {
        _beanType = beanType;
        _properties = properties;
        _nameToPropertyIndex = nameToPropertyIndex;
        _typeIds = typeIds;
        _tokens = tokens;
    }

    protected ExternalTypeHandler(ExternalTypeHandler h)
    {
        _beanType = h._beanType;
        _properties = h._properties;
        _nameToPropertyIndex = h._nameToPropertyIndex;
        int len = _properties.length;
        _typeIds = new String[len];
        _tokens = new TokenBuffer[len];
    }

    public static Builder builder(JavaType beanType) {
        return new Builder(beanType);
    }

    /**
     * Method called to start collection process by creating non-blueprint
     * instances.
     */
    public ExternalTypeHandler start() {
        return new ExternalTypeHandler(this);
    }

    /**
     * Method called to see if given property/value pair is an external type
     * id; and if so handle it. This is <b>only</b> to be called in case
     * containing POJO has similarly named property as the external type id AND
     * value is of scalar type:
     * otherwise {@link #handlePropertyValue} should be called instead.
     *
     * @return {@code true} if the property was handled as an external type id
     *   AND the type id is NOT visible (meaning: caller should skip setting
     *   this property on the bean); {@code false} otherwise
     */
    @SuppressWarnings("unchecked")
    public boolean handleTypePropertyValue(JsonParser p, DeserializationContext ctxt,
            String propName, Object bean)
        throws JacksonException
    {
        Object ob = _nameToPropertyIndex.get(propName);
        if (ob == null) {
            return false;
        }
        final String typeId = p.getString();
        // 28-Nov-2016, tatu: For [databind#291], need separate handling
        if (ob instanceof List<?>) {
            boolean result = false;
            for (Integer index : (List<Integer>) ob) {
                if (_handleTypePropertyValue(p, ctxt, propName, bean,
                        typeId, index.intValue())) {
                    result = true;
                }
            }
            return result;
        }
        return _handleTypePropertyValue(p, ctxt, propName, bean,
                typeId, ((Integer) ob).intValue());
    }

    private final boolean _handleTypePropertyValue(JsonParser p, DeserializationContext ctxt,
            String propName, Object bean, String typeId, int index)
        throws JacksonException
    {
        ExtTypedProperty prop = _properties[index];
        if (!prop.hasTypePropertyName(propName)) { // when could/should this ever happen?
            return false;
        }
        // note: CANNOT skip child values (should always be String anyway)
        // [databind#6055]: do not eagerly bind if value property is filtered by active
        // view; let complete() skip it instead
        boolean canDeserialize = (bean != null) && (_tokens[index] != null)
                && !_isFilteredByView(ctxt, index);
        // Minor optimization: deserialize properties as soon as we have all we need:
        if (canDeserialize) {
            _deserializeAndSet(p, ctxt, bean, index, typeId);
            // clear stored data, to avoid deserializing+setting twice:
            _tokens[index] = null;
        } else {
            _typeIds[index] = typeId;
        }
        // [databind#1329]: return true (= skip setting on bean) when visible=false
        //   unless EXTERNAL_TYPE_ID_ALWAYS_VISIBLE is enabled
        if (ctxt.isEnabled(MapperFeature.EXTERNAL_TYPE_ID_ALWAYS_VISIBLE)) {
            return false;
        }
        return !(prop._typeDeserializer instanceof TypeDeserializerBase tdb)
                || !tdb.isTypeIdVisible();
    }

    /**
     * Method called to ask handler to handle value of given property,
     * at point where parser points to the first token of the value.
     * Handling can mean either resolving type id it contains (if it matches type
     * property name), or by buffering the value for further use.
     *
     * @return True, if the given property was properly handled
     */
    @SuppressWarnings("unchecked")
    public boolean handlePropertyValue(JsonParser p, DeserializationContext ctxt,
            String propName, Object bean) throws JacksonException
    {
        Object ob = _nameToPropertyIndex.get(propName);
        if (ob == null) {
            return false;
        }
        // 28-Nov-2016, tatu: For [databind#291], need separate handling
        if (ob instanceof List<?>) {
            Iterator<Integer> it = ((List<Integer>) ob).iterator();
            Integer index = it.next();

            ExtTypedProperty prop = _properties[index];
            // For now, let's assume it's same type (either type id OR value)
            // for all mappings, so we'll only check first one
            if (prop.hasTypePropertyName(propName)) {
                String typeId = p.getString();
                p.skipChildren();
                _typeIds[index] = typeId;
                while (it.hasNext()) {
                    _typeIds[it.next()] = typeId;
                }
            } else {
                TokenBuffer tokens = _bufferValueWithPinnedContext(ctxt, p);
                _tokens[index] = tokens;
                while (it.hasNext()) {
                    _tokens[it.next()] = tokens;
                }
            }
            return true;
        }

        // Otherwise only maps to a single value, in which case we can
        // handle things in bit more optimal way...
        int index = ((Integer) ob).intValue();
        ExtTypedProperty prop = _properties[index];
        boolean canDeserialize;
        if (prop.hasTypePropertyName(propName)) {
            // 19-Feb-2021, tatu: as per [databind#3008], don't use "getText()"
            //    since that'll coerce null value into String "null"...
            _typeIds[index] = p.getValueAsString();
            p.skipChildren();
            canDeserialize = (bean != null) && (_tokens[index] != null)
                    && !_isFilteredByView(ctxt, index);
        } else {
            @SuppressWarnings("resource")
            TokenBuffer tokens = _bufferValueWithPinnedContext(ctxt, p);
            _tokens[index] = tokens;
            canDeserialize = (bean != null) && (_typeIds[index] != null)
                    && !_isFilteredByView(ctxt, index);
        }
        // Minor optimization: let's deserialize properties as soon as
        // we have all pertinent information:
        if (canDeserialize) {
            String typeId = _typeIds[index];
            // clear stored data, to avoid deserializing+setting twice:
            _typeIds[index] = null;
            _deserializeAndSet(p, ctxt, bean, index, typeId);
            _tokens[index] = null;
        }
        return true;
    }

    /**
     * [databind#6055]: Whether the value property at given index is filtered out by
     * the currently active {@link com.fasterxml.jackson.annotation.JsonView}; if so its
     * value and external type id are both to be skipped, same as any other view-filtered
     * property.
     */
    private boolean _isFilteredByView(DeserializationContext ctxt, int index) {
        final Class<?> activeView = ctxt.getActiveView();
        return (activeView != null)
                && !_properties[index].getProperty().visibleInView(activeView);
    }

    /**
     * Method called after JSON Object closes, and has to ensure that all external
     * type ids have been handled.
     */
    @SuppressWarnings("resource")
    public Object complete(JsonParser p, DeserializationContext ctxt, Object bean)
        throws JacksonException
    {
        final Class<?> activeView = ctxt.getActiveView();
        for (int i = 0, len = _properties.length; i < len; ++i) {
            String typeId = _typeIds[i];
            final ExtTypedProperty extProp = _properties[i];
            // [databind#6055]: if the value property is filtered out by the active
            // JsonView, skip it entirely -- both any buffered value and the external
            // type id -- instead of trying to bind it (or reporting it as missing).
            if ((activeView != null) && !extProp.getProperty().visibleInView(activeView)) {
                continue;
            }
            if (typeId == null) {
                TokenBuffer tokens = _tokens[i];
                // let's allow missing both type and property (may already have been set, too)
                // but not just one
                if (tokens == null) {
                    continue;
                }
                // [databind#118]: Need to mind natural types, for which no type id
                // will be included.
                JsonToken t = tokens.firstToken();
                if (t.isScalarValue()) { // can't be null as we never store empty buffers
                    JsonParser buffered = tokens.asParser(ctxt, p);
                    buffered.nextToken();
                    SettableBeanProperty prop = extProp.getProperty();
                    Object result = TypeDeserializer.deserializeIfNatural(buffered, ctxt, prop.getType());
                    if (result != null) {
                        prop.set(ctxt, bean, result);
                        continue;
                    }
                }
                // 26-Oct-2012, tatu: As per [databind#94], must allow use of 'defaultImpl'
                if (!extProp.hasDefaultType()) {
                    ctxt.reportPropertyInputMismatch(_beanType, extProp.getProperty().getName(),
                            "Missing external type id property '%s' (and no 'defaultImpl' specified)",
                            extProp.getTypePropertyName());
                } else  {
                    typeId = extProp.getDefaultTypeId(ctxt);
                    if (typeId == null) {
                        ctxt.reportPropertyInputMismatch(_beanType, extProp.getProperty().getName(),
"Invalid default type id for property '%s': `null` returned by TypeIdResolver",
                                extProp.getTypePropertyName());
                    }
                }
            } else if (_tokens[i] == null) {
                SettableBeanProperty prop = extProp.getProperty();

                if (prop.isRequired() ||
                        ctxt.isEnabled(DeserializationFeature.FAIL_ON_MISSING_EXTERNAL_TYPE_ID_PROPERTY)) {
                    ctxt.reportPropertyInputMismatch(bean.getClass(), prop.getName(),
                            "Missing property '%s' for external type id '%s'",
                            prop.getName(), extProp.getTypePropertyName());
                }
                return bean;
            }
            _deserializeAndSet(p, ctxt, bean, i, typeId);
        }
        return bean;
    }

    /**
     * Variant called when creation of the POJO involves buffering of creator properties
     * as well as property-based creator.
     */
    public Object complete(JsonParser p, DeserializationContext ctxt,
            PropertyValueBuffer buffer, PropertyBasedCreator creator)
        throws JacksonException
    {
        // first things first: deserialize all data buffered:
        final int len = _properties.length;
        Object[] values = new Object[len];
        final Class<?> activeView = ctxt.getActiveView();
        for (int i = 0; i < len; ++i) {
            String typeId = _typeIds[i];
            final ExtTypedProperty extProp = _properties[i];
            // [databind#6055]: if the value property is filtered out by the active
            // JsonView, skip it entirely -- leave value null instead of binding the
            // buffered value or reporting the external type id as missing.
            if ((activeView != null) && !extProp.getProperty().visibleInView(activeView)) {
                continue;
            }
            if (typeId == null) {
                // let's allow missing both type and property (may already have been set, too)
                TokenBuffer tb = _tokens[i];
                if ((tb == null)
                        // 19-Feb-2021, tatu: Both missing value and explicit `null`
                        //    should be accepted...
                        || (tb.firstToken() == JsonToken.VALUE_NULL)
                    ) {
                    continue;
                }
                // [databind#3786]: Need to mind natural types, for which no type id
                // will be included.
                JsonToken t = tb.firstToken();
                if (t.isScalarValue()) {
                    JsonParser buffered = tb.asParser(ctxt, p);
                    buffered.nextToken();
                    SettableBeanProperty prop = extProp.getProperty();
                    Object result = TypeDeserializer.deserializeIfNatural(buffered, ctxt, prop.getType());
                    if (result != null) {
                        values[i] = result;
                        // Unlike bean-based complete(), creator-based needs
                        // to assign parameter to buffer before continuing
                        if (prop.isCreatorProperty()) {
                            buffer.assignParameter(prop, result);
                        }
                        continue;
                    }
                }
                // 26-Oct-2012, tatu: As per [databind#94], must allow use of 'defaultImpl'
                if (!extProp.hasDefaultType()) {
                    ctxt.reportPropertyInputMismatch(_beanType, extProp.getProperty().getName(),
                            "Missing external type id property '%s'",
                            extProp.getTypePropertyName());
                } else {
                    typeId = extProp.getDefaultTypeId(ctxt);
                }
            }

            if (_tokens[i] != null) {
                values[i] = _deserialize(p, ctxt, i, typeId);
            } else {
                if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_MISSING_EXTERNAL_TYPE_ID_PROPERTY)) {
                    SettableBeanProperty prop = extProp.getProperty();
                    ctxt.reportPropertyInputMismatch(_beanType, prop.getName(),
                            "Missing property '%s' for external type id '%s'",
                            prop.getName(), _properties[i].getTypePropertyName());
                }
                // 03-Aug-2022, tatu: [databind#3533] to handle absent value matching
                //    present type id
                values[i] = _deserializeMissingToken(p, ctxt, i, typeId);
            }

            final SettableBeanProperty prop = extProp.getProperty();
            // also: if it's creator prop, fill in
            if (prop.isCreatorProperty()) {
                buffer.assignParameter(prop, values[i]);

                // [databind#999] And maybe there's creator property for type id too?
                SettableBeanProperty typeProp = extProp.getTypeProperty();
                // for now, should only be needed for creator properties, too
                if (typeProp != null && typeProp.isCreatorProperty()) {
                    // 31-May-2018, tatu: [databind#1328] if id is NOT plain `String`, need to
                    //    apply deserializer... fun fun.
                    final Object v;
                    if (typeProp.getType().hasRawClass(String.class)) {
                        v = typeId;
                    } else {
                        TokenBuffer tb = ctxt.bufferForInputBuffering(p);
                        tb.writeString(typeId);
                        v = typeProp.getValueDeserializer().deserialize(tb.asParserOnFirstToken(ctxt), ctxt);
                        tb.close();
                    }
                    buffer.assignParameter(typeProp, v);
                }
            }
        }
        Object bean = creator.build(ctxt, buffer);
        // third: assign non-creator properties
        for (int i = 0; i < len; ++i) {
            SettableBeanProperty prop = _properties[i].getProperty();
            if (!prop.isCreatorProperty()) {
                prop.set(ctxt, bean, values[i]);
            }
        }
        return bean;
    }

    /**
     * Buffer the value at parser's current position, pinning the buffer's parent
     * context to a snapshot of the outer parser's context at this moment. Without
     * the snapshot the TokenBuffer would hold a live reference to the outer
     * parser's context, whose {@code currentName} mutates as the parser advances
     * past this property — replaying the buffer later (after the type-id property
     * has been seen) would then expose the wrong name in
     * {@link JsonParser#streamReadContext()} to any custom deserializer.
     * [databind#2747]
     *
     * @since 3.2
     */
    @SuppressWarnings("resource")
    private static TokenBuffer _bufferValueWithPinnedContext(DeserializationContext ctxt, JsonParser p)
        throws JacksonException
    {
        TokenBuffer tokens = ctxt.bufferAsCopyOfValue(p);
        tokens.overrideParentContext(
                TokenBufferReadContext.createRootContext(p.streamReadContext()));
        return tokens;
    }

    protected final Object _deserialize(JsonParser p, DeserializationContext ctxt,
            int index, String typeId) throws JacksonException
    {
        final ExtTypedProperty extProp = _properties[index];
        JsonParser p2 = _tokens[index].asParser(ctxt, p);
        JsonToken t = p2.nextToken();
        // 29-Sep-2015, tatu: As per [databind#942], nulls need special support
        if (t == JsonToken.VALUE_NULL) {
            return null;
        }
        // [databind#2747]: invoke subtype deserializer via the known-type-id entry
        // point so the standard impls skip the wrapper-array re-encoding (which
        // would otherwise expose a synthetic array in `JsonParser.streamReadContext()`
        // to any custom deserializer examining parsing state).
        return extProp._typeDeserializer.deserializeTypedWithKnownTypeId(p2, ctxt, typeId);
    }

    // 03-Aug-2022, tatu: [databind#3533] to handle absent value matching:
    @SuppressWarnings("resource")
    protected final Object _deserializeMissingToken(JsonParser p, DeserializationContext ctxt,
            int index, String typeId)
        throws JacksonException
    {
        TokenBuffer merged = ctxt.bufferForInputBuffering(p);
        merged.writeStartArray();
        merged.writeString(typeId);
        merged.writeEndArray();

        // needs to point to START_OBJECT (or whatever first token is)
        JsonParser mp = merged.asParser(ctxt, p);
        mp.nextToken();
        return _properties[index].getProperty().deserialize(mp, ctxt);
    }

    protected final void _deserializeAndSet(JsonParser p, DeserializationContext ctxt,
            Object bean, int index, String typeId) throws JacksonException
    {
        // 11-Nov-2020, tatu: Should never get `null` passed this far,
        if (typeId == null) {
            ctxt.reportInputMismatch(_beanType, "Internal error in external Type Id handling: `null` type id passed");
        }

        final ExtTypedProperty extProp = _properties[index];
        final SettableBeanProperty prop = extProp.getProperty();
        JsonParser p2 = _tokens[index].asParser(ctxt, p);
        JsonToken t = p2.nextToken();
        // 29-Sep-2015, tatu: As per [databind#942], nulls need special support
        if (t == JsonToken.VALUE_NULL) {
            prop.set(ctxt, bean, null);
            return;
        }
        // [databind#2747]: invoke subtype deserializer via the known-type-id entry
        // point so the standard impls skip the wrapper-array re-encoding (which
        // would otherwise expose a synthetic array in `JsonParser.streamReadContext()`
        // to any custom deserializer examining parsing state).
        Object value = extProp._typeDeserializer.deserializeTypedWithKnownTypeId(p2, ctxt, typeId);
        prop.set(ctxt, bean, value);
    }

    /*
    /**********************************************************
    /* Helper classes
    /**********************************************************
     */

    public static class Builder
    {
        private final JavaType _beanType;

        private final List<ExtTypedProperty> _properties = new ArrayList<>();
        private final Map<String, Object> _nameToPropertyIndex = new HashMap<>();

        protected Builder(JavaType t) {
            _beanType = t;
        }

        @Deprecated // since 3.2; use variant that accepts aliases
        public void addExternal(SettableBeanProperty property, TypeDeserializer typeDeser) {
            addExternal(property, typeDeser, null);
        }

        /**
         * Variant that also accepts aliases of the value property, so that an
         * external type id can resolve value via an aliased property name.
         *
         * @since 3.2
         */
        // [databind#3209]
        public void addExternal(SettableBeanProperty property, TypeDeserializer typeDeser,
                List<PropertyName> valueAliases)
        {
            Integer index = _properties.size();
            _properties.add(new ExtTypedProperty(property, typeDeser));
            _addPropertyIndex(property.getName(), index);
            _addPropertyIndex(typeDeser.getPropertyName(), index);
            if (valueAliases != null) {
                for (PropertyName alias : valueAliases) {
                    _addPropertyIndex(alias.getSimpleName(), index);
                }
            }
        }

        private void _addPropertyIndex(String name, Integer index) {
            Object ob = _nameToPropertyIndex.get(name);
            if (ob == null) {
                _nameToPropertyIndex.put(name, index);
            } else if (ob instanceof List<?>) {
                @SuppressWarnings("unchecked")
                List<Object> list = (List<Object>) ob;
                list.add(index);
            } else {
                List<Object> list = new LinkedList<>();
                list.add(ob);
                list.add(index);
                _nameToPropertyIndex.put(name, list);
            }
        }

        /**
         * Method called after all external properties have been assigned, to further
         * link property with polymorphic value with possible property for type id
         * itself. This is needed to support type ids as Creator properties.
         */
        public ExternalTypeHandler build(BeanPropertyMap otherProps) {
            // 21-Jun-2016, tatu: as per [databind#999], may need to link type id property also
            final int len = _properties.size();
            ExtTypedProperty[] extProps = new ExtTypedProperty[len];
            for (int i = 0; i < len; ++i) {
                ExtTypedProperty extProp = _properties.get(i);
                String typePropId = extProp.getTypePropertyName();
                SettableBeanProperty typeProp = otherProps.findDefinition(typePropId);
                if (typeProp != null) {
                    extProp.linkTypeProperty(typeProp);
                }
                extProps[i] = extProp;
            }
            return new ExternalTypeHandler(_beanType, extProps, _nameToPropertyIndex,
                    null, null);
        }
    }

    private final static class ExtTypedProperty
    {
        private final SettableBeanProperty _property;
        private final TypeDeserializer _typeDeserializer;
        private final String _typePropertyName;

        private SettableBeanProperty _typeProperty;

        public ExtTypedProperty(SettableBeanProperty property, TypeDeserializer typeDeser)
        {
            _property = property;
            _typeDeserializer = typeDeser;
            _typePropertyName = typeDeser.getPropertyName();
        }

        /**
         * @since 2.8
         */
        public void linkTypeProperty(SettableBeanProperty p) {
            _typeProperty = p;
        }

        public boolean hasTypePropertyName(String n) {
            return n.equals(_typePropertyName);
        }

        public boolean hasDefaultType() {
            return _typeDeserializer.hasDefaultImpl();
        }

        /**
         * Specialized called when we need to expose type id of `defaultImpl` when
         * serializing: we may need to expose it for assignment to a property, or
         * it may be requested as visible for some other reason.
         */
        public String getDefaultTypeId(DeserializationContext ctxt) {
            Class<?> defaultType = _typeDeserializer.getDefaultImpl();
            if (defaultType == null) {
                return null;
            }
            return _typeDeserializer.getTypeIdResolver().idFromValueAndType(ctxt, null, defaultType);
        }

        public String getTypePropertyName() { return _typePropertyName; }

        public SettableBeanProperty getProperty() {
            return _property;
        }

        public SettableBeanProperty getTypeProperty() {
            return _typeProperty;
        }
    }
}
