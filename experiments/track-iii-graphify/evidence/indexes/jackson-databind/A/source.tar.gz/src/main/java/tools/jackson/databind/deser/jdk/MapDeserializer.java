package tools.jackson.databind.deser.jdk;

import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonIncludeProperties;

import tools.jackson.core.*;
import tools.jackson.databind.*;
import tools.jackson.databind.annotation.JacksonStdImpl;
import tools.jackson.databind.deser.*;
import tools.jackson.databind.deser.ReadableObjectId.Referring;
import tools.jackson.databind.deser.bean.PropertyBasedCreator;
import tools.jackson.databind.deser.bean.PropertyValueBuffer;
import tools.jackson.databind.deser.std.ContainerDeserializerBase;
import tools.jackson.databind.introspect.AnnotatedMember;
import tools.jackson.databind.jsontype.TypeDeserializer;
import tools.jackson.databind.type.LogicalType;
import tools.jackson.databind.util.IgnorePropertiesUtil;

/**
 * Basic deserializer that can take JSON "Object" structure and
 * construct a {@link java.util.Map} instance, with typed contents.
 *<p>
 * Note: for untyped content (one indicated by passing Object.class
 * as the type), {@link UntypedObjectDeserializer} is used instead.
 * It can also construct {@link java.util.Map}s, but not with specific
 * POJO types, only other containers and primitives/wrappers.
 */
@JacksonStdImpl
public class MapDeserializer
    extends ContainerDeserializerBase<Map<Object,Object>>
{
    // // Configuration: typing, deserializers

    /**
     * Key deserializer to use; either passed via constructor
     * (when indicated by annotations), or resolved when
     * {@link #resolve} is called;
     */
    protected final KeyDeserializer _keyDeserializer;

    /**
     * Flag set to indicate that the key type is
     * {@link java.lang.String} (or {@link java.lang.Object}, for
     * which String is acceptable), <b>and</b> that the
     * default Jackson key deserializer would be used.
     * If both are true, can optimize handling.
     */
    protected boolean _standardStringKey;

    /**
     * Value deserializer.
     */
    protected final ValueDeserializer<Object> _valueDeserializer;

    /**
     * If value instances have polymorphic type information, this
     * is the type deserializer that can handle it
     */
    protected final TypeDeserializer _valueTypeDeserializer;

    // // Instance construction settings:

    protected final ValueInstantiator _valueInstantiator;

    /**
     * Deserializer that is used iff delegate-based creator is
     * to be used for deserializing from JSON Object.
     */
    protected ValueDeserializer<Object> _delegateDeserializer;

    /**
     * If the Map is to be instantiated using non-default constructor
     * or factory method
     * that takes one or more named properties as argument(s),
     * this creator is used for instantiation.
     */
    protected PropertyBasedCreator _propertyBasedCreator;

    protected final boolean _hasDefaultCreator;

    // // Any properties to ignore if seen?

    protected Set<String> _ignorableProperties;

    protected Set<String> _includableProperties;

    /**
     * Helper object used for name-based filtering
     */
    protected IgnorePropertiesUtil.Checker _inclusionChecker;


    /**
     * Flag used to check, whether the {@link tools.jackson.core.StreamReadCapability#DUPLICATE_PROPERTIES}
     * can be applied, because the Map has declared value type of {@code java.lang.Object}.
     */
    protected final boolean _checkDupSquash;

    /**
     * Flag that indicates whether value merging should be applied when
     * deserializing content (Map values) during Map merge operation.
     * Set to {@code false} when content type has ConfigOverride with
     * {@code mergeable = false}.
     *
     * @since 3.2
     */
    protected final boolean _mergeValues;

    /*
    /**********************************************************************
    /* Life-cycle
    /**********************************************************************
     */

    public MapDeserializer(JavaType mapType, ValueInstantiator valueInstantiator,
            KeyDeserializer keyDeser, ValueDeserializer<Object> valueDeser,
            TypeDeserializer valueTypeDeser)
    {
        super(mapType, null, null);
        _keyDeserializer = keyDeser;
        _valueDeserializer = valueDeser;
        _valueTypeDeserializer = valueTypeDeser;
        _valueInstantiator = valueInstantiator;
        _hasDefaultCreator = valueInstantiator.canCreateUsingDefault();
        _delegateDeserializer = null;
        _propertyBasedCreator = null;
        _standardStringKey = _isStdKeyDeser(mapType, keyDeser);
        _inclusionChecker = null;
        _checkDupSquash = mapType.getContentType().hasRawClass(Object.class);
        _mergeValues = true;
    }

    /**
     * Copy-constructor that can be used by sub-classes to allow
     * copy-on-write styling copying of settings of an existing instance.
     */
    protected MapDeserializer(MapDeserializer src)
    {
        super(src);
        _keyDeserializer = src._keyDeserializer;
        _valueDeserializer = src._valueDeserializer;
        _valueTypeDeserializer = src._valueTypeDeserializer;
        _valueInstantiator = src._valueInstantiator;
        _propertyBasedCreator = src._propertyBasedCreator;
        _delegateDeserializer = src._delegateDeserializer;
        _hasDefaultCreator = src._hasDefaultCreator;
        // should we make a copy here?
        _ignorableProperties = src._ignorableProperties;
        _includableProperties = src._includableProperties;
        _inclusionChecker = src._inclusionChecker;

        _standardStringKey = src._standardStringKey;
        _checkDupSquash = src._checkDupSquash;
        _mergeValues = src._mergeValues;
    }

    protected MapDeserializer(MapDeserializer src,
            KeyDeserializer keyDeser, ValueDeserializer<Object> valueDeser,
            TypeDeserializer valueTypeDeser,
            NullValueProvider nuller,
            Set<String> ignorable)
    {
       this(src, keyDeser,valueDeser, valueTypeDeser, nuller, ignorable, null);
    }

    /**
     * @since 2.12
     */
    protected MapDeserializer(MapDeserializer src,
            KeyDeserializer keyDeser, ValueDeserializer<Object> valueDeser,
            TypeDeserializer valueTypeDeser,
            NullValueProvider nuller,
            Set<String> ignorable,
            Set<String> includable)
    {
        super(src, nuller, src._unwrapSingle);
        _keyDeserializer = keyDeser;
        _valueDeserializer = valueDeser;
        _valueTypeDeserializer = valueTypeDeser;
        _valueInstantiator = src._valueInstantiator;
        _propertyBasedCreator = src._propertyBasedCreator;
        _delegateDeserializer = src._delegateDeserializer;
        _hasDefaultCreator = src._hasDefaultCreator;
        _ignorableProperties = ignorable;
        _includableProperties = includable;
        _inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(ignorable, includable);

        _standardStringKey = _isStdKeyDeser(_containerType, keyDeser);
        _checkDupSquash = src._checkDupSquash;
        _mergeValues = src._mergeValues;
    }

    /**
     * @since 3.2
     */
    protected MapDeserializer(MapDeserializer src, boolean mergeValues)
    {
        super(src);
        _keyDeserializer = src._keyDeserializer;
        _valueDeserializer = src._valueDeserializer;
        _valueTypeDeserializer = src._valueTypeDeserializer;
        _valueInstantiator = src._valueInstantiator;
        _propertyBasedCreator = src._propertyBasedCreator;
        _delegateDeserializer = src._delegateDeserializer;
        _hasDefaultCreator = src._hasDefaultCreator;
        _ignorableProperties = src._ignorableProperties;
        _includableProperties = src._includableProperties;
        _inclusionChecker = src._inclusionChecker;

        _standardStringKey = src._standardStringKey;
        _checkDupSquash = src._checkDupSquash;
        _mergeValues = mergeValues;
    }

    /**
     * Fluent factory method used to create a copy with slightly
     * different settings. When sub-classing, MUST be overridden.
     */
    protected MapDeserializer withResolved(KeyDeserializer keyDeser,
            TypeDeserializer valueTypeDeser, ValueDeserializer<?> valueDeser,
            NullValueProvider nuller,
            Set<String> ignorable)
    {
        return withResolved(keyDeser, valueTypeDeser, valueDeser, nuller, ignorable, _includableProperties);
    }

    /**
     * @since 2.12
     */
    @SuppressWarnings("unchecked")
    protected MapDeserializer withResolved(KeyDeserializer keyDeser,
            TypeDeserializer valueTypeDeser, ValueDeserializer<?> valueDeser,
            NullValueProvider nuller,
            Set<String> ignorable, Set<String> includable)
    {
        if ((_keyDeserializer == keyDeser) && (_valueDeserializer == valueDeser)
                && (_valueTypeDeserializer == valueTypeDeser) && (_nullProvider == nuller)
                && (_ignorableProperties == ignorable) && (_includableProperties == includable)) {
            return this;
        }
        return new MapDeserializer(this,
                keyDeser, (ValueDeserializer<Object>) valueDeser, valueTypeDeser,
                nuller, ignorable, includable);
    }

    /**
     * @since 3.2
     */
    protected MapDeserializer withMergeValues(boolean mergeValues) {
        if (_mergeValues == mergeValues) {
            return this;
        }
        return new MapDeserializer(this, mergeValues);
    }

    /**
     * Helper method used to check whether we can just use the default key
     * deserialization, where JSON String becomes Java String.
     */
    protected final boolean _isStdKeyDeser(JavaType mapType, KeyDeserializer keyDeser)
    {
        if (keyDeser == null) {
            return true;
        }
        JavaType keyType = mapType.getKeyType();
        if (keyType == null) { // assumed to be Object
            return true;
        }
        Class<?> rawKeyType = keyType.getRawClass();
        return ((rawKeyType == String.class || rawKeyType == Object.class)
                && isDefaultKeyDeserializer(keyDeser));
    }

    public void setIgnorableProperties(Set<String> ignorable) {
        _ignorableProperties = (ignorable == null || ignorable.isEmpty()) ?
                null : ignorable;
        _inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(_ignorableProperties, _includableProperties);
    }

    public void setIncludableProperties(Set<String> includable) {
        _includableProperties = includable;
        _inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(_ignorableProperties, _includableProperties);
    }

    /*
    /**********************************************************************
    /* Validation, post-processing (ResolvableDeserializer)
    /**********************************************************************
     */

    @Override
    public void resolve(DeserializationContext ctxt)
    {
        // May need to resolve types for delegate- and/or property-based creators:
        if (_valueInstantiator.canCreateUsingDelegate()) {
            JavaType delegateType = _valueInstantiator.getDelegateType(ctxt.getConfig());
            if (delegateType == null) {
                ctxt.reportBadDefinition(_containerType, String.format(
                        "Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingDelegate()', but null for 'getDelegateType()'",
                        _containerType,
                        _valueInstantiator.getClass().getName()));
            }
            // Theoretically should be able to get CreatorProperty for delegate
            // parameter to pass; but things get tricky because DelegateCreator
            // may contain injectable values. So, for now, let's pass nothing.
            _delegateDeserializer = findDeserializer(ctxt, delegateType, null);
        } else if (_valueInstantiator.canCreateUsingArrayDelegate()) {
            JavaType delegateType = _valueInstantiator.getArrayDelegateType(ctxt.getConfig());
            if (delegateType == null) {
                ctxt.reportBadDefinition(_containerType, String.format(
                        "Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingArrayDelegate()', but null for 'getArrayDelegateType()'",
                        _containerType,
                        _valueInstantiator.getClass().getName()));
            }
            _delegateDeserializer = findDeserializer(ctxt, delegateType, null);
        }
        if (_valueInstantiator.canCreateFromObjectWith()) {
            SettableBeanProperty[] creatorProps = _valueInstantiator.getFromObjectArguments(ctxt.getConfig());
            _propertyBasedCreator = PropertyBasedCreator.construct(ctxt, _valueInstantiator, creatorProps,
                    ctxt.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES));
        }
        _standardStringKey = _isStdKeyDeser(_containerType, _keyDeserializer);
    }

    /**
     * Method called to finalize setup of this deserializer,
     * when it is known for which property deserializer is needed for.
     */
    @Override
    public ValueDeserializer<?> createContextual(DeserializationContext ctxt,
            BeanProperty property)
    {
        KeyDeserializer keyDeser = _keyDeserializer;
        if (keyDeser == null) {
            keyDeser = ctxt.findKeyDeserializer(_containerType.getKeyType(), property);
        } else {
            if (keyDeser instanceof ContextualKeyDeserializer ckd) {
                keyDeser = ckd.createContextual(ctxt, property);
            }
        }

        ValueDeserializer<?> valueDeser = _valueDeserializer;
        // [databind#125]: May have a content converter
        if (property != null) {
            valueDeser = findConvertingContentDeserializer(ctxt, property, valueDeser);
        }
        final JavaType vt = _containerType.getContentType();
        if (valueDeser == null) {
            valueDeser = ctxt.findContextualValueDeserializer(vt, property);
        } else { // if directly assigned, probably not yet contextual, so:
            valueDeser = ctxt.handleSecondaryContextualization(valueDeser, property, vt);
        }
        TypeDeserializer vtd = _valueTypeDeserializer;
        if (vtd != null) {
            vtd = vtd.forProperty(property);
        }
        Set<String> ignored = _ignorableProperties;
        Set<String> included = _includableProperties;
        AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
        if (_neitherNull(intr, property)) {
            AnnotatedMember member = property.getMember();
            if (member != null) {
                final DeserializationConfig config = ctxt.getConfig();
                JsonIgnoreProperties.Value ignorals = intr.findPropertyIgnoralByName(ctxt.getConfig(), member);
                if (ignorals != null) {
                    Set<String> ignoresToAdd = ignorals.findIgnoredForDeserialization();
                    if (!ignoresToAdd.isEmpty()) {
                        if (ignored == null) {
                            ignored = new HashSet<>(ignoresToAdd);
                        } else {
                            ignored = new HashSet<>(ignored);
                            ignored.addAll(ignoresToAdd);
                        }
                    }
                }
                JsonIncludeProperties.Value inclusions = intr.findPropertyInclusionByName(config, member);
                if (inclusions != null) {
                    Set<String> includedToAdd = inclusions.getIncluded();
                    if (includedToAdd != null) {
                        Set<String> newIncluded = new HashSet<>();
                        if (included == null) {
                            newIncluded = new HashSet<>(includedToAdd);
                        } else {
                            for (String str : includedToAdd) {
                                if (included.contains(str)) {
                                    newIncluded.add(str);
                                }
                            }
                        }
                        included = newIncluded;
                    }
                }
            }
        }
        MapDeserializer deser = withResolved(keyDeser, vtd, valueDeser,
                findContentNullProvider(ctxt, property, valueDeser), ignored, included);
        // [databind#3205]: Check if content type has mergeable disabled
        Boolean contentMergeable = ctxt.getConfig().getDefaultMergeable(vt.getRawClass());
        if (Boolean.FALSE.equals(contentMergeable)) {
            deser = deser.withMergeValues(false);
        }
        return deser;
    }

    /*
    /**********************************************************************
    /* ContainerDeserializerBase API
    /**********************************************************************
     */

    @Override
    public ValueDeserializer<Object> getContentDeserializer() {
        return _valueDeserializer;
    }

    @Override
    public ValueInstantiator getValueInstantiator() {
        return _valueInstantiator;
    }

    /*
    /**********************************************************************
    /* ValueDeserializer API
    /**********************************************************************
     */

    /**
     * Turns out that these are expensive enough to create so that caching
     * does make sense.
     *<p>
     * IMPORTANT: but, note, that instances CANNOT BE CACHED if there is
     * a value type deserializer; this caused an issue with 2.4.4 of
     * JAXB Annotations (failing a test).
     * It is also possible that some other settings could make deserializers
     * un-cacheable; but on the other hand, caching can make a big positive
     * difference with performance... so it's a hard choice.
     */
    @Override
    public boolean isCachable() {
        // As per [databind#735], existence of value or key deserializer (only passed
        // if annotated to use non-standard one) should also prevent caching.
        return (_valueDeserializer == null)
                && (_keyDeserializer == null)
                && (_valueTypeDeserializer == null)
                && (_ignorableProperties == null)
                && (_includableProperties == null);
    }

    @Override // since 2.12
    public LogicalType logicalType() {
        return LogicalType.Map;
    }

    @Override
    @SuppressWarnings("unchecked")
    public Map<Object,Object> deserialize(JsonParser p, DeserializationContext ctxt)
        throws JacksonException
    {
        if (_propertyBasedCreator != null) {
            return _deserializeUsingCreator(p, ctxt);
        }
        if (_delegateDeserializer != null) {
            return (Map<Object,Object>) _valueInstantiator.createUsingDelegate(ctxt,
                    _delegateDeserializer.deserialize(p, ctxt));
        }
        if (!_hasDefaultCreator) {
            return (Map<Object,Object> ) ctxt.handleMissingInstantiator(getMapClass(),
                    getValueInstantiator(), p,
                    "no default constructor found");
        }
        switch (p.currentTokenId()) {
        case JsonTokenId.ID_START_OBJECT:
        case JsonTokenId.ID_END_OBJECT:
        case JsonTokenId.ID_PROPERTY_NAME:
            final Map<Object,Object> result = (Map<Object,Object>) _valueInstantiator.createUsingDefault(ctxt);
            if (_standardStringKey) {
                return _readAndBindStringKeyMap(p, ctxt, result);
            }
            return _readAndBind(p, ctxt, result);
        case JsonTokenId.ID_STRING:
            // (empty) String may be ok however; or single-String-arg ctor
            return _deserializeFromStringForContainer(p, ctxt);
        case JsonTokenId.ID_START_ARRAY:
            // Empty array, or single-value wrapped in array?
            return _deserializeFromArray(p, ctxt);
        default:
        }
        return (Map<Object,Object>) ctxt.handleUnexpectedToken(getValueType(ctxt), p);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Map<Object,Object> deserialize(JsonParser p, DeserializationContext ctxt,
            Map<Object,Object> result)
        throws JacksonException
    {
        // [databind#631]: Assign current value, to be accessible by custom deserializers
        p.assignCurrentValue(result);

        // Ok: must point to START_OBJECT or PROPERTY_NAME
        JsonToken t = p.currentToken();
        if (t != JsonToken.START_OBJECT && t != JsonToken.PROPERTY_NAME) {
            return (Map<Object,Object>) ctxt.handleUnexpectedToken(getValueType(ctxt), p);
        }
        // 21-Apr-2017, tatu: Need separate methods to do proper merging
        if (_standardStringKey) {
            _readAndUpdateStringKeyMap(p, ctxt, result);
            return result;
        }
        _readAndUpdate(p, ctxt, result);
        return result;
    }

    @Override
    public Object deserializeWithType(JsonParser p, DeserializationContext ctxt,
            TypeDeserializer typeDeserializer)
        throws JacksonException
    {
        // In future could check current token... for now this should be enough:
        return typeDeserializer.deserializeTypedFromObject(p, ctxt);
    }

    /*
    /**********************************************************************
    /* Other public accessors
    /**********************************************************************
     */

    @SuppressWarnings("unchecked")
    public final Class<?> getMapClass() { return (Class<Map<Object,Object>>) _containerType.getRawClass(); }

    /*
    /**********************************************************************
    /* Internal methods, non-merging deserialization
    /**********************************************************************
     */

    protected final Map<Object,Object> _readAndBind(JsonParser p, DeserializationContext ctxt,
            Map<Object,Object> result) throws JacksonException
    {
        String keyStr;
        if (p.isExpectedStartObjectToken()) {
            keyStr = p.nextName();
        } else {
            JsonToken t = p.currentToken();
            if (t != JsonToken.PROPERTY_NAME) {
                _checkIsEndObject(ctxt, t);
                return result;
            }
            keyStr = p.currentName();
        }
        if (keyStr == null) {
            return result;
        }

        MapReferringAccumulator referringAccumulator = null;
        boolean useObjectId = _valueDeserializer.getObjectIdReader(ctxt) != null;
        if (useObjectId) {
            referringAccumulator = new MapReferringAccumulator(_containerType.getContentType().getRawClass(),
                    result);
        }

        // [databind#3188] Cache capability once outside the loop
        final boolean skipNullKeys = (_keyDeserializer instanceof NullKeySkippable nks)
                && nks.skipNullKeys(ctxt);

        for (; keyStr != null; keyStr = p.nextName()) {
            Object key = _keyDeserializer.deserializeKey(keyStr, ctxt);
            // And then the value...
            JsonToken t = p.nextToken();
            // [databind#3188] Skip entry when key deserializer requests null-key skipping
            if (skipNullKeys && key == null) {
                p.skipChildren(); // no-op for scalar tokens; safe to call unconditionally
                continue;
            }
            if ((_inclusionChecker != null) && _inclusionChecker.shouldIgnore(keyStr)) {
                p.skipChildren();
                continue;
            }
            try {
                // Note: must handle null explicitly here; value deserializers won't
                Object value;
                if (t == JsonToken.VALUE_NULL) {
                    if (_skipNullValues) {
                        continue;
                    }
                    value = null;
                } else {
                    value = _deserializeNoNullChecks(p, ctxt);
                }

                if (value == null) {
                    value = _nullProvider.getNullValue(ctxt);

                    if (value == null && _skipNullValues) {
                        continue;
                    }
                }

                if (useObjectId) {
                    referringAccumulator.put(key, value);
                } else {
                    Object oldValue = result.put(key, value);
                    if (oldValue != null) {
                        _squashDups(ctxt, result, key, oldValue, value);
                    }
                }
            } catch (UnresolvedForwardReference reference) {
                handleUnresolvedReference(ctxt, referringAccumulator, key, reference);
            } catch (Exception e) {
                wrapAndThrow(ctxt, e, result, keyStr);
            }
        }
        return result;
    }

    /**
     * Optimized method used when keys can be deserialized as plain old
     * {@link java.lang.String}s, and there is no custom deserialized
     * specified.
     */
    protected final Map<Object,Object> _readAndBindStringKeyMap(JsonParser p, DeserializationContext ctxt,
            Map<Object,Object> result) throws JacksonException
    {
        String key;
        if (p.isExpectedStartObjectToken()) {
            key = p.nextName();
        } else {
            JsonToken t = p.currentToken();
            if (t != JsonToken.PROPERTY_NAME) {
                _checkIsEndObject(ctxt, t);
                return result;
            }
            key = p.currentName();
        }
        if (key == null) {
            return result;
        }

        MapReferringAccumulator referringAccumulator = null;
        boolean useObjectId = (_valueDeserializer.getObjectIdReader(ctxt) != null);
        if (useObjectId) {
            referringAccumulator = new MapReferringAccumulator(_containerType.getContentType().getRawClass(), result);
        }

        for (; key != null; key = p.nextName()) {
            JsonToken t = p.nextToken();
            if ((_inclusionChecker != null) && _inclusionChecker.shouldIgnore(key)) {
                p.skipChildren();
                continue;
            }
            try {
                // Note: must handle null explicitly here; value deserializers won't
                Object value;
                if (t == JsonToken.VALUE_NULL) {
                    if (_skipNullValues) {
                        continue;
                    }
                    value = null;
                } else {
                    value = _deserializeNoNullChecks(p, ctxt);
                }

                if (value == null) {
                    value = _nullProvider.getNullValue(ctxt);

                    if (value == null && _skipNullValues) {
                        continue;
                    }
                }

                if (useObjectId) {
                    referringAccumulator.put(key, value);
                } else {
                    Object oldValue = result.put(key, value);
                    if (oldValue != null) {
                        _squashDups(ctxt, result, key, oldValue, value);
                    }
                }
            } catch (UnresolvedForwardReference reference) {
                handleUnresolvedReference(ctxt, referringAccumulator, key, reference);
            } catch (Exception e) {
                wrapAndThrow(ctxt, e, result, key);
            }
        }
        // 23-Mar-2015, tatu: TODO: verify we got END_OBJECT?

        return result;
    }

    @SuppressWarnings("unchecked")
    public Map<Object,Object> _deserializeUsingCreator(JsonParser p, DeserializationContext ctxt)
        throws JacksonException
    {
        final PropertyBasedCreator creator = _propertyBasedCreator;
        // null -> no ObjectIdReader for Maps (yet?)
        PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, null, false);

        String key;
        if (p.isExpectedStartObjectToken()) {
            key = p.nextName();
        } else if (p.hasToken(JsonToken.PROPERTY_NAME)) {
            key = p.currentName();
        } else {
            key = null;
        }

        // [databind#3188] Cache capability once outside the loop
        final boolean skipNullKeys = (_keyDeserializer instanceof NullKeySkippable nks)
                && nks.skipNullKeys(ctxt);

        for (; key != null; key = p.nextName()) {
            JsonToken t = p.nextToken(); // to get to value
            if ((_inclusionChecker != null) && _inclusionChecker.shouldIgnore(key)) {
                p.skipChildren(); // and skip it (in case of array/object)
                continue;
            }
            // creator property?
            SettableBeanProperty prop = creator.findCreatorProperty(key);
            if (prop != null) {
                // Last property to set?
                if (buffer.assignParameter(prop, prop.deserialize(p, ctxt))) {
                    p.nextToken(); // from value to END_OBJECT or PROPERTY_NAME
                    Map<Object,Object> result;
                    try {
                        result = (Map<Object,Object>)creator.build(ctxt, buffer);
                    } catch (Exception e) {
                        return wrapAndThrow(ctxt, e, _containerType.getRawClass(), key);
                    }
                    return _readAndBind(p, ctxt, result);
                }
                continue;
            }
            // other property? needs buffering
            Object actualKey = _keyDeserializer.deserializeKey(key, ctxt);
            // [databind#3188] Skip entry when key deserializer requests null-key skipping
            if (skipNullKeys && actualKey == null) {
                p.skipChildren(); // no-op for scalar tokens; safe to call unconditionally
                continue;
            }
            Object value;

            try {
                if (t == JsonToken.VALUE_NULL) {
                    if (_skipNullValues) {
                        continue;
                    }
                    value = null;
                } else {
                    value = _deserializeNoNullChecks(p, ctxt);
                }

                if (value == null) {
                    value = _nullProvider.getNullValue(ctxt);

                    if (value == null && _skipNullValues) {
                        continue;
                    }
                }
            } catch (Exception e) {
                wrapAndThrow(ctxt, e, _containerType.getRawClass(), key);
                return null;
            }
            buffer.bufferMapProperty(actualKey, value);
        }
        // end of JSON object?
        // if so, can just construct and leave...
        try {
            return (Map<Object,Object>)creator.build(ctxt, buffer);
        } catch (Exception e) {
            wrapAndThrow(ctxt, e, _containerType.getRawClass(), key);
            return null;
        }
    }

    /*
    /**********************************************************************
    /* Internal methods, non-merging deserialization
    /**********************************************************************
     */

    protected final void _readAndUpdate(JsonParser p, DeserializationContext ctxt,
            Map<Object,Object> result) throws JacksonException
    {
        final ValueDeserializer<Object> valueDes = _valueDeserializer;
        final TypeDeserializer typeDeser = _valueTypeDeserializer;

        // Note: assumption is that Object Id handling can't really work with merging
        // and thereby we can (and should) just drop that part

        String keyStr;
        if (p.isExpectedStartObjectToken()) {
            keyStr = p.nextName();
        } else {
            JsonToken t = p.currentToken();
            if (t != JsonToken.PROPERTY_NAME) {
                _checkIsEndObject(ctxt, t);
                return;
            }
            keyStr = p.currentName();
        }

        // [databind#3188] Cache capability once outside the loop
        final boolean skipNullKeys = (_keyDeserializer instanceof NullKeySkippable nks)
                && nks.skipNullKeys(ctxt);

        for (; keyStr != null; keyStr = p.nextName()) {
            Object key = _keyDeserializer.deserializeKey(keyStr, ctxt);
            // And then the value...
            JsonToken t = p.nextToken();
            // [databind#3188] Skip entry when key deserializer requests null-key skipping
            if (skipNullKeys && key == null) {
                p.skipChildren(); // no-op for scalar tokens; safe to call unconditionally
                continue;
            }
            if ((_inclusionChecker != null) && _inclusionChecker.shouldIgnore(keyStr)) {
                p.skipChildren();
                continue;
            }
            try {
                // Note: must handle null explicitly here, can't merge etc
                if (t == JsonToken.VALUE_NULL) {
                    if (_skipNullValues) {
                        continue;
                    }
                    result.put(key, _nullProvider.getNullValue(ctxt));
                    continue;
                }
                // [databind#3205]: Only attempt to merge content values if
                // content type's ConfigOverride allows it
                Object old = _mergeValues ? result.get(key) : null;
                Object value;
                if (old != null) {
                    if (typeDeser == null) {
                        value = valueDes.deserialize(p, ctxt, old);
                    } else {
                        value = valueDes.deserializeWithType(p, ctxt, typeDeser, old);
                    }
                } else {
                    value = _deserializeNoNullChecks(p, ctxt);
                }

                if (value == null) {
                    value = _nullProvider.getNullValue(ctxt);

                    if (value == null && _skipNullValues) {
                        continue;
                    }
                }

                if (value != old) {
                    result.put(key, value);
                }
            } catch (Exception e) {
                wrapAndThrow(ctxt, e, result, keyStr);
            }
        }
    }

    /**
     * Optimized method used when keys can be deserialized as plain old
     * {@link java.lang.String}s, and there is no custom deserializer
     * specified.
     */
    protected final void _readAndUpdateStringKeyMap(JsonParser p, DeserializationContext ctxt,
            Map<Object,Object> result) throws JacksonException
    {
        final ValueDeserializer<Object> valueDes = _valueDeserializer;
        final TypeDeserializer typeDeser = _valueTypeDeserializer;

        // Note: assumption is that Object Id handling can't really work with merging
        // and thereby we can (and should) just drop that part

        String key;
        if (p.isExpectedStartObjectToken()) {
            key = p.nextName();
        } else {
            JsonToken t = p.currentToken();
            if (t != JsonToken.PROPERTY_NAME) {
                _checkIsEndObject(ctxt, t);
                return;
            }
            key = p.currentName();
        }

        for (; key != null; key = p.nextName()) {
            JsonToken t = p.nextToken();
            if ((_inclusionChecker != null) && _inclusionChecker.shouldIgnore(key)) {
                p.skipChildren();
                continue;
            }
            try {
                // Note: must handle null explicitly here, can't merge etc
                if (t == JsonToken.VALUE_NULL) {
                    if (_skipNullValues) {
                        continue;
                    }
                    result.put(key, _nullProvider.getNullValue(ctxt));
                    continue;
                }
                // [databind#3205]: Only attempt to merge content values if
                // content type's ConfigOverride allows it
                Object old = _mergeValues ? result.get(key) : null;
                Object value;
                if (old != null) {
                    if (typeDeser == null) {
                        value = valueDes.deserialize(p, ctxt, old);
                    } else {
                        value = valueDes.deserializeWithType(p, ctxt, typeDeser, old);
                    }
                } else {
                    value = _deserializeNoNullChecks(p, ctxt);
                }

                if (value == null) {
                    value = _nullProvider.getNullValue(ctxt);

                    if (value == null && _skipNullValues) {
                        continue;
                    }
                }

                if (value != old) {
                    result.put(key, value);
                }
            } catch (Exception e) {
                wrapAndThrow(ctxt, e, result, key);
            }
        }
    }

    /**
     * Deserialize the content of the map.
     * If _valueTypeDeserializer is null, use _valueDeserializer.deserialize; if non-null,
     * use _valueDeserializer.deserializeWithType to deserialize value.
     * This method only performs deserialization and does not consider _skipNullValues, _nullProvider, etc.
     */
    protected Object _deserializeNoNullChecks(JsonParser p, DeserializationContext ctxt)
        throws JacksonException
    {
        if (_valueTypeDeserializer == null) {
            return _valueDeserializer.deserialize(p, ctxt);
        }
        return _valueDeserializer.deserializeWithType(p, ctxt, _valueTypeDeserializer);
    }

    @SuppressWarnings("unchecked")
    protected void _squashDups(final DeserializationContext ctxt,
            final Map<Object, Object> result,
            final Object key, final Object oldValue, final Object newValue)
    {
        if (_checkDupSquash && ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES)) {
            if (oldValue instanceof List<?>) {
                ((List<Object>) oldValue).add(newValue);
                result.put(key, oldValue);
            } else {
                ArrayList<Object> l = new ArrayList<>();
                l.add(oldValue);
                l.add(newValue);
                result.put(key, l);
            }
        }
    }

    /*
    /**********************************************************************
    /* Internal methods, other
    /**********************************************************************
     */

    // @since 3.1
    protected void _checkIsEndObject(DeserializationContext ctxt, JsonToken t) {
        if (t != JsonToken.END_OBJECT) {
            ctxt.reportWrongTokenException(this, JsonToken.PROPERTY_NAME, null);
        }
    }

    private void handleUnresolvedReference(DeserializationContext ctxt,
            MapReferringAccumulator accumulator,
            Object key, UnresolvedForwardReference reference)
        throws JacksonException
    {
        if (accumulator == null) {
            ctxt.reportInputMismatch(this,
                    "Unresolved forward reference but no identity info: "+reference);
        }
        Referring referring = accumulator.handleUnresolvedReference(reference, key); // lgtm [java/dereferenced-value-may-be-null]
        reference.getRoid().appendReferring(referring);
    }

    final static class MapReferringAccumulator {
        private final Class<?> _valueType;
        private final Map<Object,Object> _result;
        /**
         * A list of {@link MapReferring} to maintain ordering.
         */
        private final List<MapReferring> _accumulator = new ArrayList<MapReferring>();

        public MapReferringAccumulator(Class<?> valueType, Map<Object, Object> result) {
            _valueType = valueType;
            _result = result;
        }

        public void put(Object key, Object value)
        {
            if (_accumulator.isEmpty()) {
                _result.put(key, value);
            } else {
                MapReferring ref = _accumulator.get(_accumulator.size() - 1);
                ref.next.put(key, value);
            }
        }

        public Referring handleUnresolvedReference(UnresolvedForwardReference reference, Object key)
        {
            MapReferring id = new MapReferring(this, reference, _valueType, key);
            _accumulator.add(id);
            return id;
        }

        public void resolveForwardReference(DeserializationContext ctxt, Object id, Object value)
            throws JacksonException
        {
            Iterator<MapReferring> iterator = _accumulator.iterator();
            // Resolve ordering after resolution of an id. This means either:
            // 1- adding to the result map in case of the first unresolved id.
            // 2- merge the content of the resolved id with its previous unresolved id.
            Map<Object,Object> previous = _result;
            while (iterator.hasNext()) {
                MapReferring ref = iterator.next();
                if (ref.hasId(id)) {
                    iterator.remove();
                    previous.put(ref.key, value);
                    previous.putAll(ref.next);
                    return;
                }
                previous = ref.next;
            }

            throw new IllegalArgumentException("Trying to resolve a forward reference with id [" + id
                    + "] that wasn't previously seen as unresolved.");
        }

        /**
         * Replace a resolved item in the result map. Called when the bound item
         * is rebound (e.g., builder → built object).
         *
         * @param oldItem Item to replace (Builder)
         * @param newItem Item to replace {@code oldItem} with (Built value)
         *
         * @since 3.2
         */
        public void replaceResolvedItem(Object oldItem, Object newItem) {
            replaceInMap(_result, oldItem, newItem);
            // Pending accumulator entries may also hold the old item if a later
            // forward ref hasn't yet resolved.
            for (MapReferring ref : _accumulator) {
                replaceInMap(ref.next, oldItem, newItem);
            }
        }

        private static void replaceInMap(Map<Object, Object> map, Object oldItem, Object newItem) {
            // Identity match: oldItem is the exact bound delegate (e.g. Builder).
            for (Map.Entry<Object, Object> entry : map.entrySet()) {
                if (entry.getValue() == oldItem) {
                    entry.setValue(newItem);
                }
            }
        }
    }

    /**
     * Helper class to maintain processing order of value.
     * The resolved object associated with {@link #key} comes before the values in
     * {@link #next}.
     */
    static class MapReferring extends Referring {
        private final MapReferringAccumulator _parent;

        public final Map<Object, Object> next = new LinkedHashMap<>();
        public final Object key;

        MapReferring(MapReferringAccumulator parent, UnresolvedForwardReference ref,
                Class<?> valueType, Object key)
        {
            super(ref, valueType);
            _parent = parent;
            this.key = key;
        }

        @Override
        public void handleResolvedForwardReference(DeserializationContext ctxt, Object id, Object value)
            throws JacksonException
        {
            _parent.resolveForwardReference(ctxt, id, value);
        }

        @Override
        public void handleItemRebind(Object oldItem, Object newItem) {
            _parent.replaceResolvedItem(oldItem, newItem);
        }
    }
}
