package tools.jackson.databind.deser.jdk;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.Nulls;

import tools.jackson.core.*;
import tools.jackson.core.exc.StreamReadException;
import tools.jackson.databind.*;
import tools.jackson.databind.annotation.JacksonStdImpl;
import tools.jackson.databind.deser.NullValueProvider;
import tools.jackson.databind.deser.impl.NullsConstantProvider;
import tools.jackson.databind.deser.impl.NullsFailProvider;
import tools.jackson.databind.deser.std.StdDeserializer;
import tools.jackson.databind.exc.InvalidNullException;
import tools.jackson.databind.jsontype.TypeDeserializer;
import tools.jackson.databind.type.LogicalType;
import tools.jackson.databind.util.AccessPattern;
import tools.jackson.databind.util.ArrayBuilders;

/**
 * Container for deserializers used for instantiating "primitive arrays",
 * arrays that contain non-object java primitive types.
 */
public abstract class PrimitiveArrayDeserializers<T>
    extends StdDeserializer<T>
{
    /**
     * Specific override for this instance (from proper, or global per-type overrides)
     * to indicate whether single value may be taken to mean an unwrapped one-element array
     * or not. If null, left to global defaults.
     */
    protected final Boolean _unwrapSingle;

    private transient Object _emptyValue;

    /**
     * Flag that indicates need for special handling; either failing
     * (throw exception) or skipping
     */
    protected final NullValueProvider _nuller;

    /*
    /********************************************************
    /* Life-cycle
    /********************************************************
     */

    protected PrimitiveArrayDeserializers(Class<T> cls) {
        super(cls);
        _unwrapSingle = null;
        _nuller = null;
    }

    protected PrimitiveArrayDeserializers(PrimitiveArrayDeserializers<?> base,
            NullValueProvider nuller, Boolean unwrapSingle) {
        super(base._valueClass);
        _unwrapSingle = unwrapSingle;
        _nuller = nuller;
    }

    public static ValueDeserializer<?> forType(Class<?> rawType)
    {
        // Start with more common types...
        if (rawType == Integer.TYPE) {
            return IntDeser.instance;
        }
        if (rawType == Long.TYPE) {
            return LongDeser.instance;
        }

        if (rawType == Byte.TYPE) {
            return new ByteDeser();
        }
        if (rawType == Short.TYPE) {
            return new ShortDeser();
        }
        if (rawType == Float.TYPE) {
            return new FloatDeser();
        }
        if (rawType == Double.TYPE) {
            return new DoubleDeser();
        }
        if (rawType == Boolean.TYPE) {
            return new BooleanDeser();
        }
        if (rawType == Character.TYPE) {
            return new CharDeser();
        }
        throw new IllegalArgumentException("Unknown primitive array element type: "+rawType);
    }

    @Override
    public ValueDeserializer<?> createContextual(DeserializationContext ctxt,
            BeanProperty property)
    {
        Boolean unwrapSingle = findFormatFeature(ctxt, property, _valueClass,
                JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
        NullValueProvider nuller = null;

        Nulls nullStyle = findContentNullStyle(ctxt, property);
        if (nullStyle == Nulls.SKIP) {
            nuller = NullsConstantProvider.skipper();
        } else if (nullStyle == Nulls.FAIL) {
            if (property == null) {
                // 09-Dec-2019, tatu: [databind#2567] need to ensure correct target type
                nuller = NullsFailProvider.constructForRootValue(ctxt.constructType(_valueClass.getComponentType()));
            } else {
                // 09-Dec-2019, tatu: [databind#2567] need to ensure correct target type
                nuller = NullsFailProvider.constructForProperty(property, property.getType().getContentType());
            }
        }
        if ((Objects.equals(unwrapSingle, _unwrapSingle)) && (nuller == _nuller)) {
            return this;
        }
        return withResolved(nuller, unwrapSingle);
    }

    /*
    /********************************************************
    /* Abstract methods for sub-classes to implement
    /********************************************************
     */

    /**
     * @since 2.9
     */
    protected abstract T _concat(T oldValue, T newValue);

    protected abstract T handleSingleElementUnwrapped(JsonParser p,
            DeserializationContext ctxt) throws JacksonException;

    /**
     * @since 2.9
     */
    protected abstract PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller,
            Boolean unwrapSingle);

    // since 2.9
    protected abstract T _constructEmpty();

    /*
    /********************************************************
    /* Default implementations
    /********************************************************
     */

    @Override // since 2.12
    public LogicalType logicalType() {
        return LogicalType.Array;
    }

    @Override // since 2.9
    public Boolean supportsUpdate(DeserializationConfig config) {
        return Boolean.TRUE;
    }

    @Override
    public AccessPattern getEmptyAccessPattern() {
        // Empty values shareable freely
        return AccessPattern.CONSTANT;
    }

    @Override
    public Object getEmptyValue(DeserializationContext ctxt) {
        Object empty = _emptyValue;
        if (empty == null) {
            _emptyValue = empty = _constructEmpty();
        }
        return empty;
    }

    @Override
    public Object deserializeWithType(JsonParser p, DeserializationContext ctxt,
            TypeDeserializer typeDeserializer)
        throws JacksonException
    {
        // Should there be separate handling for base64 stuff?
        // for now this should be enough:
        return typeDeserializer.deserializeTypedFromArray(p, ctxt);
    }

    @Override
    public T deserialize(JsonParser p, DeserializationContext ctxt, T existing) throws JacksonException
    {
        T newValue = deserialize(p, ctxt);
        if (existing == null) {
            return newValue;
        }
        int len = Array.getLength(existing);
        if (len == 0) {
            return newValue;
        }
        return _concat(existing, newValue);
    }

    /*
    /********************************************************
    /* Helper methods for sub-classes
    /********************************************************
     */

    @SuppressWarnings("unchecked")
    protected T handleNonArray(JsonParser p, DeserializationContext ctxt) throws JacksonException
    {
        final boolean canWrap = (_unwrapSingle == Boolean.TRUE) ||
                ((_unwrapSingle == null) &&
                        ctxt.isEnabled(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY));
        // 12-Mar-2025, tatu: as per [databind#4650] things get bit tricky with
        //   single-element wrapping of a String value
        // Let's still call _deserializeFromString() for empty strings no matter what,
        // and for all values if wrapping not enabled
        // [databind#3349]: for non-empty strings, delegate to handleUnexpectedToken
        if (p.hasToken(JsonToken.VALUE_STRING)) {
            if (!canWrap || _isBlank(p.getString())) {
                return _deserializeFromStringForContainer(p, ctxt);
            }
        }
        if (canWrap) {
            return handleSingleElementUnwrapped(p, ctxt);
        }
        return (T) ctxt.handleUnexpectedToken(getValueType(ctxt), p);
    }

    protected void _failOnNull(DeserializationContext ctxt) throws JacksonException
    {
        throw InvalidNullException.from(ctxt, null, ctxt.constructType(_valueClass));
    }

    /*
    /********************************************************
    /* Actual deserializers: efficient String[], char[] deserializers
    /********************************************************
     */

    @JacksonStdImpl
    final static class CharDeser
        extends PrimitiveArrayDeserializers<char[]>
    {
        public CharDeser() { super(char[].class); }
        protected CharDeser(CharDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
            super(base, nuller, unwrapSingle);
        }

        @Override
        protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller,
                Boolean unwrapSingle) {
            // 11-Dec-2015, tatu: Not sure how re-wrapping would work; omit
            return this;
        }

        @Override
        protected char[] _constructEmpty() {
            return new char[0];
        }

        @Override
        public char[] deserialize(JsonParser p, DeserializationContext ctxt) throws JacksonException
        {
            // Won't take arrays, must get a String (could also convert other tokens to Strings...
            // but let's not bother yet, doesn't seem to make sense)
            JsonToken t = p.currentToken();
            if (t == JsonToken.VALUE_STRING) {
                // note: CANNOT return shared internal buffer, must copy:
                char[] buffer = p.getStringCharacters();
                int offset = p.getStringOffset();
                int len = p.getStringLength();

                return Arrays.copyOfRange(buffer, offset, offset + len);
            }
            if (p.isExpectedStartArrayToken()) {
                // Let's actually build as a String, then get chars
                StringBuilder sb = new StringBuilder(64);
                while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
                    String str;
                    if (t == JsonToken.VALUE_STRING) {
                        str = p.getString();
                    } else if (t == JsonToken.VALUE_NULL) {
                        if (_nuller != null) {
                            _nuller.getNullValue(ctxt);
                            continue;
                        }
                        char value = (char) _verifyNullForPrimitive(ctxt, p, '\0');
                        sb.append(value);
                        continue;
                    } else {
                        CharSequence cs = (CharSequence) ctxt.handleUnexpectedToken(getValueType(ctxt), p);
                        str = cs.toString();
                    }
                    if (str.length() != 1) {
                        ctxt.reportInputMismatch(this,
"Cannot convert a JSON String of length %d into a char element of char array", str.length());
                    }
                    sb.append(str.charAt(0));
                }
                return sb.toString().toCharArray();
            }
            // or, maybe an embedded object?
            if (t == JsonToken.VALUE_EMBEDDED_OBJECT) {
                Object ob = p.getEmbeddedObject();
                if (ob == null) return null;
                if (ob instanceof char[] charArray) {
                    return charArray;
                }
                if (ob instanceof String string) {
                    return string.toCharArray();
                }
                // 04-Feb-2011, tatu: byte[] can be converted; assuming base64 is wanted
                if (ob instanceof byte[] byteArray) {
                    return Base64Variants.getDefaultVariant().encode(byteArray, false).toCharArray();
                }
                // not recognized, just fall through
            }
            return (char[]) ctxt.handleUnexpectedToken(getValueType(ctxt), p);
        }

        @Override
        protected char[] handleSingleElementUnwrapped(JsonParser p,
                DeserializationContext ctxt) throws JacksonException {
            // not sure how this should work...
            return (char[]) ctxt.handleUnexpectedToken(getValueType(ctxt), p);
        }

        @Override
        protected char[] _concat(char[] oldValue, char[] newValue) {
            int len1 = oldValue.length;
            int len2 = newValue.length;
            char[] result = Arrays.copyOf(oldValue, len1+len2);
            System.arraycopy(newValue, 0, result, len1, len2);
            return result;
        }
    }

    /*
    /**********************************************************
    /* Actual deserializers: primivate array desers
    /**********************************************************
     */

    @JacksonStdImpl
    final static class BooleanDeser
        extends PrimitiveArrayDeserializers<boolean[]>
    {
        public BooleanDeser() { super(boolean[].class); }
        protected BooleanDeser(BooleanDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
            super(base, nuller, unwrapSingle);
        }

        @Override
        protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller,
                Boolean unwrapSingle) {
            return new BooleanDeser(this, nuller, unwrapSingle);
        }

        @Override
        protected boolean[] _constructEmpty() {
            return new boolean[0];
        }

        @Override
        public boolean[] deserialize(JsonParser p, DeserializationContext ctxt)
            throws JacksonException
        {
            if (!p.isExpectedStartArrayToken()) {
                return handleNonArray(p, ctxt);
            }
            ArrayBuilders.BooleanBuilder builder = ctxt.getArrayBuilders().getBooleanBuilder();
            boolean[] chunk = builder.resetAndStart();
            int ix = 0;

            try {
                JsonToken t;
                while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
                    boolean value;
                    if (t == JsonToken.VALUE_TRUE) {
                        value = true;
                    } else if (t == JsonToken.VALUE_FALSE) {
                        value = false;
                    } else if (t == JsonToken.VALUE_NULL) {
                        if (_nuller != null) {
                            _nuller.getNullValue(ctxt);
                            continue;
                        }
                        value = (boolean) _verifyNullForPrimitive(ctxt, p, false);
                    } else {
                        value = _parseBooleanPrimitive(p, ctxt);
                    }
                    if (ix >= chunk.length) {
                        chunk = builder.appendCompletedChunk(chunk, ix);
                        ix = 0;
                    }
                    chunk[ix++] = value;
                }
            } catch (Exception e) {
                throw DatabindException.wrapWithPath(ctxt, e,
                        new JacksonException.Reference(chunk, builder.bufferedSize() + ix));
            }
            return builder.completeAndClearBuffer(chunk, ix);
        }

        @Override
        protected boolean[] handleSingleElementUnwrapped(JsonParser p,
                DeserializationContext ctxt) throws JacksonException {
            return new boolean[] { _parseBooleanPrimitive(p, ctxt) };
        }

        @Override
        protected boolean[] _concat(boolean[] oldValue, boolean[] newValue) {
            int len1 = oldValue.length;
            int len2 = newValue.length;
            boolean[] result = Arrays.copyOf(oldValue, len1+len2);
            System.arraycopy(newValue, 0, result, len1, len2);
            return result;
        }
    }

    /**
     * When dealing with byte arrays we have one more alternative (compared
     * to int/long/shorts): base64 encoded data.
     */
    @JacksonStdImpl
    final static class ByteDeser
        extends PrimitiveArrayDeserializers<byte[]>
    {
        public ByteDeser() { super(byte[].class); }
        protected ByteDeser(ByteDeser base, NullValueProvider nuller,Boolean unwrapSingle) {
            super(base, nuller, unwrapSingle);
        }

        @Override
        protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller,
                Boolean unwrapSingle) {
            return new ByteDeser(this, nuller, unwrapSingle);
        }

        @Override
        protected byte[] _constructEmpty() {
            return new byte[0];
        }

        @Override // since 2.12
        public LogicalType logicalType() {
            // 30-May-2020, tatu: while technically an array, logically contains
            //    binary data so...
            return LogicalType.Binary;
        }

        @Override
        public byte[] deserialize(JsonParser p, DeserializationContext ctxt) throws JacksonException
        {
            JsonToken t = p.currentToken();

            // Most likely case: base64 encoded String?
            if (t == JsonToken.VALUE_STRING) {
                try {
                    return p.getBinaryValue(ctxt.getBase64Variant());
                } catch (StreamReadException | DatabindException e) {
                    // 25-Nov-2016, tatu: related to [databind#1425], try to convert
                    //   to a more usable one, as it's not really a JSON-level parse
                    //   exception, but rather binding from JSON String into base64 decoded
                    //   binary data
                    String msg = e.getOriginalMessage();
                    if (msg.contains("base64")) {
                        return (byte[]) ctxt.handleWeirdStringValue(byte[].class,
                                p.getString(), msg);
                    }
                    throw e;
                }
            }
            // 31-Dec-2009, tatu: Also may be hidden as embedded Object
            if (t == JsonToken.VALUE_EMBEDDED_OBJECT) {
                Object ob = p.getEmbeddedObject();
                if (ob == null) return null;
                if (ob instanceof byte[] byteArray) {
                    return byteArray;
                }
            }
            if (!p.isExpectedStartArrayToken()) {
                return handleNonArray(p, ctxt);
            }
            ArrayBuilders.ByteBuilder builder = ctxt.getArrayBuilders().getByteBuilder();
            byte[] chunk = builder.resetAndStart();
            int ix = 0;

            try {
                while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
                    // whether we should allow truncating conversions?
                    byte value;
                    if (t == JsonToken.VALUE_NUMBER_INT) {
                        value = p.getByteValue(); // note: may throw due to overflow
                    } else {
                        // should probably accept nulls as 0
                        if (t == JsonToken.VALUE_NULL) {
                            if (_nuller != null) {
                                _nuller.getNullValue(ctxt);
                                continue;
                            }
                            value = (byte) _verifyNullForPrimitive(ctxt, p, (byte) 0);
                        } else {
                            value = _parseBytePrimitive(p, ctxt);
                        }
                    }
                    if (ix >= chunk.length) {
                        chunk = builder.appendCompletedChunk(chunk, ix);
                        ix = 0;
                    }
                    chunk[ix++] = value;
                }
            } catch (Exception e) {
                throw DatabindException.wrapWithPath(ctxt, e,
                        new JacksonException.Reference(chunk, builder.bufferedSize() + ix));
            }
            return builder.completeAndClearBuffer(chunk, ix);
        }

        @Override
        protected byte[] handleSingleElementUnwrapped(JsonParser p,
                DeserializationContext ctxt) throws JacksonException
        {
            byte value;
            JsonToken t = p.currentToken();
            if (t == JsonToken.VALUE_NUMBER_INT) {
                value = p.getByteValue(); // note: may throw due to overflow
            } else {
                // should we accept nulls as null for byte[], or { 0 } ?
                if (t == JsonToken.VALUE_NULL) {
                    if (_nuller != null) {
                        _nuller.getNullValue(ctxt);
                        return (byte[]) getEmptyValue(ctxt);
                    }
                    value = (byte) _verifyNullForPrimitive(ctxt, p, (byte) 0);
                }
                Number n = (Number) ctxt.handleUnexpectedToken(getValueType(ctxt), p);
                value = n.byteValue();
            }
            return new byte[] { value };
        }

        @Override
        protected byte[] _concat(byte[] oldValue, byte[] newValue) {
            int len1 = oldValue.length;
            int len2 = newValue.length;
            byte[] result = Arrays.copyOf(oldValue, len1+len2);
            System.arraycopy(newValue, 0, result, len1, len2);
            return result;
        }
    }

    @JacksonStdImpl
    final static class ShortDeser
        extends PrimitiveArrayDeserializers<short[]>
    {
        public ShortDeser() { super(short[].class); }
        protected ShortDeser(ShortDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
            super(base, nuller, unwrapSingle);
        }

        @Override
        protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller,
                Boolean unwrapSingle) {
            return new ShortDeser(this, nuller, unwrapSingle);
        }

        @Override
        protected short[] _constructEmpty() {
            return new short[0];
        }

        @Override
        public short[] deserialize(JsonParser p, DeserializationContext ctxt) throws JacksonException
        {
            if (!p.isExpectedStartArrayToken()) {
                return handleNonArray(p, ctxt);
            }
            ArrayBuilders.ShortBuilder builder = ctxt.getArrayBuilders().getShortBuilder();
            short[] chunk = builder.resetAndStart();
            int ix = 0;

            try {
                JsonToken t;
                while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
                    short value;
                    if (t == JsonToken.VALUE_NULL) {
                        if (_nuller != null) {
                            _nuller.getNullValue(ctxt);
                            continue;
                        }
                        value = (short) _verifyNullForPrimitive(ctxt, p, (short) 0);
                    } else {
                        value = _parseShortPrimitive(p, ctxt);
                    }
                    if (ix >= chunk.length) {
                        chunk = builder.appendCompletedChunk(chunk, ix);
                        ix = 0;
                    }
                    chunk[ix++] = value;
                }
            } catch (Exception e) {
                throw DatabindException.wrapWithPath(ctxt, e,
                        new JacksonException.Reference(chunk, builder.bufferedSize() + ix));
            }
            return builder.completeAndClearBuffer(chunk, ix);
        }

        @Override
        protected short[] handleSingleElementUnwrapped(JsonParser p,
                DeserializationContext ctxt) throws JacksonException {
            return new short[] { _parseShortPrimitive(p, ctxt) };
        }

        @Override
        protected short[] _concat(short[] oldValue, short[] newValue) {
            int len1 = oldValue.length;
            int len2 = newValue.length;
            short[] result = Arrays.copyOf(oldValue, len1+len2);
            System.arraycopy(newValue, 0, result, len1, len2);
            return result;
        }
    }

    @JacksonStdImpl
    final static class IntDeser
        extends PrimitiveArrayDeserializers<int[]>
    {
        public final static IntDeser instance = new IntDeser();

        public IntDeser() { super(int[].class); }
        protected IntDeser(IntDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
            super(base, nuller, unwrapSingle);
        }

        @Override
        protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller,
                Boolean unwrapSingle) {
            return new IntDeser(this, nuller, unwrapSingle);
        }

        @Override
        protected int[] _constructEmpty() {
            return new int[0];
        }

        @Override
        public int[] deserialize(JsonParser p, DeserializationContext ctxt) throws JacksonException
        {
            if (!p.isExpectedStartArrayToken()) {
                return handleNonArray(p, ctxt);
            }
            ArrayBuilders.IntBuilder builder = ctxt.getArrayBuilders().getIntBuilder();
            int[] chunk = builder.resetAndStart();
            int ix = 0;

            try {
                JsonToken t;
                while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
                    int value;
                    if (t == JsonToken.VALUE_NUMBER_INT) {
                        value = p.getIntValue();
                    } else if (t == JsonToken.VALUE_NULL) {
                        if (_nuller != null) {
                            _nuller.getNullValue(ctxt);
                            continue;
                        }
                        value = (int) _verifyNullForPrimitive(ctxt, p, 0);
                    } else {
                        value = _parseIntPrimitive(p, ctxt);
                    }
                    if (ix >= chunk.length) {
                        chunk = builder.appendCompletedChunk(chunk, ix);
                        ix = 0;
                    }
                    chunk[ix++] = value;
                }
            } catch (Exception e) {
                throw DatabindException.wrapWithPath(ctxt, e,
                        new JacksonException.Reference(chunk, builder.bufferedSize() + ix));
            }
            return builder.completeAndClearBuffer(chunk, ix);
        }

        @Override
        protected int[] handleSingleElementUnwrapped(JsonParser p,
                DeserializationContext ctxt) throws JacksonException {
            return new int[] { _parseIntPrimitive(p, ctxt) };
        }

        @Override
        protected int[] _concat(int[] oldValue, int[] newValue) {
            int len1 = oldValue.length;
            int len2 = newValue.length;
            int[] result = Arrays.copyOf(oldValue, len1+len2);
            System.arraycopy(newValue, 0, result, len1, len2);
            return result;
        }
    }

    @JacksonStdImpl
    final static class LongDeser
        extends PrimitiveArrayDeserializers<long[]>
    {
        public final static LongDeser instance = new LongDeser();

        public LongDeser() { super(long[].class); }
        protected LongDeser(LongDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
            super(base, nuller, unwrapSingle);
        }

        @Override
        protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller,
                Boolean unwrapSingle) {
            return new LongDeser(this, nuller, unwrapSingle);
        }

        @Override
        protected long[] _constructEmpty() {
            return new long[0];
        }

        @Override
        public long[] deserialize(JsonParser p, DeserializationContext ctxt) throws JacksonException
        {
            if (!p.isExpectedStartArrayToken()) {
                return handleNonArray(p, ctxt);
            }
            ArrayBuilders.LongBuilder builder = ctxt.getArrayBuilders().getLongBuilder();
            long[] chunk = builder.resetAndStart();
            int ix = 0;

            try {
                JsonToken t;
                while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
                    long value;
                    if (t == JsonToken.VALUE_NUMBER_INT) {
                        value = p.getLongValue();
                    } else if (t == JsonToken.VALUE_NULL) {
                        if (_nuller != null) {
                            _nuller.getNullValue(ctxt);
                            continue;
                        }
                        value = (long) _verifyNullForPrimitive(ctxt, p, 0L);
                    } else {
                        value = _parseLongPrimitive(p, ctxt);
                    }
                    if (ix >= chunk.length) {
                        chunk = builder.appendCompletedChunk(chunk, ix);
                        ix = 0;
                    }
                    chunk[ix++] = value;
                }
            } catch (Exception e) {
                throw DatabindException.wrapWithPath(ctxt, e,
                        new JacksonException.Reference(chunk, builder.bufferedSize() + ix));
            }
            return builder.completeAndClearBuffer(chunk, ix);
        }

        @Override
        protected long[] handleSingleElementUnwrapped(JsonParser p,
                DeserializationContext ctxt) throws JacksonException {
            return new long[] { _parseLongPrimitive(p, ctxt) };
        }

        @Override
        protected long[] _concat(long[] oldValue, long[] newValue) {
            int len1 = oldValue.length;
            int len2 = newValue.length;
            long[] result = Arrays.copyOf(oldValue, len1+len2);
            System.arraycopy(newValue, 0, result, len1, len2);
            return result;
        }
    }

    @JacksonStdImpl
    final static class FloatDeser
        extends PrimitiveArrayDeserializers<float[]>
    {
        public FloatDeser() { super(float[].class); }
        protected FloatDeser(FloatDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
            super(base, nuller, unwrapSingle);
        }

        @Override
        protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller,
                Boolean unwrapSingle) {
            return new FloatDeser(this, nuller, unwrapSingle);
        }

        @Override
        protected float[] _constructEmpty() {
            return new float[0];
        }

        @Override
        public float[] deserialize(JsonParser p, DeserializationContext ctxt)
            throws JacksonException
        {
            if (!p.isExpectedStartArrayToken()) {
                float[] decoded = _deserializeBinaryVector(p, ctxt);
                if (decoded != null) {
                    return decoded;
                }
                return handleNonArray(p, ctxt);
            }
            ArrayBuilders.FloatBuilder builder = ctxt.getArrayBuilders().getFloatBuilder();
            float[] chunk = builder.resetAndStart();
            int ix = 0;

            try {
                JsonToken t;
                while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
                    // whether we should allow truncating conversions?
                    if (t == JsonToken.VALUE_NULL) {
                        if (_nuller != null) {
                            _nuller.getNullValue(ctxt);
                            continue;
                        }
                    }
                    float value = _parseFloatPrimitive(p, ctxt);
                    if (ix >= chunk.length) {
                        chunk = builder.appendCompletedChunk(chunk, ix);
                        ix = 0;
                    }
                    chunk[ix++] = value;
                }
            } catch (Exception e) {
                throw DatabindException.wrapWithPath(ctxt, e,
                        new JacksonException.Reference(chunk, builder.bufferedSize() + ix));
            }
            return builder.completeAndClearBuffer(chunk, ix);
        }

        @Override
        protected float[] handleSingleElementUnwrapped(JsonParser p,
                DeserializationContext ctxt) throws JacksonException {
            return new float[] { _parseFloatPrimitive(p, ctxt) };
        }

        @Override
        protected float[] _concat(float[] oldValue, float[] newValue) {
            int len1 = oldValue.length;
            int len2 = newValue.length;
            float[] result = Arrays.copyOf(oldValue, len1+len2);
            System.arraycopy(newValue, 0, result, len1, len2);
            return result;
        }

        private float[] _deserializeBinaryVector(JsonParser p, DeserializationContext ctxt)
            throws JacksonException
        {
            JsonToken t = p.currentToken();
            byte[] packed = null;

            // Typical textual format case: base64 encoded String (for Packed Binary Vector)
            if (t == JsonToken.VALUE_STRING) {
                try {
                    packed = p.getBinaryValue(ctxt.getBase64Variant());
                } catch (StreamReadException | DatabindException e) {
                    // [databind#1425], try to convert to a more usable one, as it's not really
                    // a JSON-level parse exception, but rather binding from JSON String into
                    // base64 decoded  binary data
                    String msg = e.getOriginalMessage();
                    if (msg.contains("base64")) {
                        return (float[]) ctxt.handleWeirdStringValue(float[].class,
                                p.getString(), msg);
                    }
                    throw e;
                }
            } else if (t == JsonToken.VALUE_EMBEDDED_OBJECT) {
                // Typical for binary formats
                Object ob = p.getEmbeddedObject();
                if (ob instanceof byte[] byteArray) {
                    packed = byteArray;
                } else if (ob == null || (ob instanceof float[])) {
                    return (float[]) ob;
                }
            }
            // Packed Binary Vector case
            if (packed != null) {
                return _unpack(ctxt, packed);
            }
            return null;
        }

        private float[] _unpack(DeserializationContext ctxt, byte[] bytes) throws JacksonException {
            final int bytesLen = bytes.length;
            if ((bytesLen & 3) != 0) {
                return (float[]) ctxt.reportInputMismatch(handledType(),
                        "Vector length for Packed Binary Float Vector (%d) not a multiple of 4 bytes", bytesLen);
            }
            final int vectorLen = bytesLen >> 2;
            final float[] floats = new float[vectorLen];
            for (int in = 0, out = 0; in < bytesLen; ) {
                int packed = (bytes[in++] << 24)
                        | ((bytes[in++] & 0xFF) << 16)
                        | ((bytes[in++] & 0xFF) << 8)
                        | (bytes[in++] & 0xFF);
                floats[out++] = Float.intBitsToFloat(packed);
            }
            return floats;
        }
    }

    @JacksonStdImpl
    final static class DoubleDeser
        extends PrimitiveArrayDeserializers<double[]>
    {
        public DoubleDeser() { super(double[].class); }
        protected DoubleDeser(DoubleDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
            super(base, nuller, unwrapSingle);
        }

        @Override
        protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller,
                Boolean unwrapSingle) {
            return new DoubleDeser(this, nuller, unwrapSingle);
        }

        @Override
        protected double[] _constructEmpty() {
            return new double[0];
        }

        @Override
        public double[] deserialize(JsonParser p, DeserializationContext ctxt) throws JacksonException
        {
            if (!p.isExpectedStartArrayToken()) {
                double[] decoded = _deserializeBinaryVector(p, ctxt);
                if (decoded != null) {
                    return decoded;
                }
                return handleNonArray(p, ctxt);
            }
            ArrayBuilders.DoubleBuilder builder = ctxt.getArrayBuilders().getDoubleBuilder();
            double[] chunk = builder.resetAndStart();
            int ix = 0;

            try {
                JsonToken t;
                while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
                    if (t == JsonToken.VALUE_NULL) {
                        if (_nuller != null) {
                            _nuller.getNullValue(ctxt);
                            continue;
                        }
                    }
                    double value = _parseDoublePrimitive(p, ctxt);
                    if (ix >= chunk.length) {
                        chunk = builder.appendCompletedChunk(chunk, ix);
                        ix = 0;
                    }
                    chunk[ix++] = value;
                }
            } catch (Exception e) {
                throw DatabindException.wrapWithPath(ctxt, e,
                        new JacksonException.Reference(chunk, builder.bufferedSize() + ix));
            }
            return builder.completeAndClearBuffer(chunk, ix);
        }

        @Override
        protected double[] handleSingleElementUnwrapped(JsonParser p,
                DeserializationContext ctxt)
            throws JacksonException
        {
            return new double[] { _parseDoublePrimitive(p, ctxt) };
        }

        @Override
        protected double[] _concat(double[] oldValue, double[] newValue) {
            int len1 = oldValue.length;
            int len2 = newValue.length;
            double[] result = Arrays.copyOf(oldValue, len1+len2);
            System.arraycopy(newValue, 0, result, len1, len2);
            return result;
        }

        private double[] _deserializeBinaryVector(JsonParser p, DeserializationContext ctxt)
            throws JacksonException
        {
            JsonToken t = p.currentToken();
            byte[] packed = null;

            // Typical textual format case: base64 encoded String (for Packed Binary Vector)
            if (t == JsonToken.VALUE_STRING) {
                try {
                    packed = p.getBinaryValue(ctxt.getBase64Variant());
                } catch (StreamReadException | DatabindException e) {
                    // [databind#1425], try to convert to a more usable one, as it's not really
                    // a JSON-level parse exception, but rather binding from JSON String into
                    // base64 decoded  binary data
                    String msg = e.getOriginalMessage();
                    if (msg.contains("base64")) {
                        return (double[]) ctxt.handleWeirdStringValue(double[].class,
                                p.getString(), msg);
                    }
                    throw e;
                }
            } else if (t == JsonToken.VALUE_EMBEDDED_OBJECT) {
                // Typical for binary formats
                Object ob = p.getEmbeddedObject();
                if (ob instanceof byte[] byteArray) {
                    packed = byteArray;
                } else if (ob == null || (ob instanceof double[])) {
                    return (double[]) ob;
                }
            }
            // Packed Binary Vector case
            if (packed != null) {
                return _unpack(ctxt, packed);
            }
            return null;
        }

        private double[] _unpack(DeserializationContext ctxt, byte[] bytes) throws JacksonException
        {
            final int bytesLen = bytes.length;
            if ((bytesLen & 7) != 0) {
                return (double[]) ctxt.reportInputMismatch(handledType(),
                        "Vector length for Packed Binary Double Vector (%d) not a multiple of 8 bytes", bytesLen);
            }
            final int vectorLen = bytesLen >> 3;
            final double[] doubles = new double[vectorLen];
            for (int in = 0, out = 0; in < bytesLen; ) {
                int packed1 = (bytes[in++] << 24)
                        | ((bytes[in++] & 0xFF) << 16)
                        | ((bytes[in++] & 0xFF) << 8)
                        | (bytes[in++] & 0xFF);
                int packed2 = (bytes[in++] << 24)
                        | ((bytes[in++] & 0xFF) << 16)
                        | ((bytes[in++] & 0xFF) << 8)
                        | (bytes[in++] & 0xFF);
                long packed = ((long) packed1 << 32) | (packed2 & 0xFFFFFFFFL);
                doubles[out++] = Double.longBitsToDouble(packed);
            }
            return doubles;
        }
    }
}
