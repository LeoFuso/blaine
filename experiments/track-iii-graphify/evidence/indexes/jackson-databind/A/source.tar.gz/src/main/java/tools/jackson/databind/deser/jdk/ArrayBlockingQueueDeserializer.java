package tools.jackson.databind.deser.jdk;

import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;

import tools.jackson.core.JacksonException;
import tools.jackson.core.JsonParser;
import tools.jackson.databind.*;
import tools.jackson.databind.annotation.JacksonStdImpl;
import tools.jackson.databind.deser.NullValueProvider;
import tools.jackson.databind.deser.ValueInstantiator;
import tools.jackson.databind.introspect.AnnotatedClass;
import tools.jackson.databind.jsontype.TypeDeserializer;

/**
 * We need a custom deserializer both because {@link ArrayBlockingQueue} has no
 * default constructor AND because it has size limit used for constructing
 * underlying storage automatically.
 */
@JacksonStdImpl
public class ArrayBlockingQueueDeserializer
    extends CollectionDeserializer
{
    /*
    /**********************************************************************
    /* Life-cycle
    /**********************************************************************
     */

    // @since 3.1
    public ArrayBlockingQueueDeserializer(JavaType containerType,
            ValueDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser,
            ValueInstantiator valueInstantiator,
            AnnotatedClass classInfo)
    {
        super(containerType, valueDeser, valueTypeDeser, valueInstantiator, classInfo);
    }

    /**
     * Constructor used when creating contextualized instances.
     *
     * @since 3.1
     */
     protected ArrayBlockingQueueDeserializer(JavaType containerType,
            ValueDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser,
            ValueInstantiator valueInstantiator,
            ValueDeserializer<Object> delegateDeser,
            NullValueProvider nuller, Boolean unwrapSingle,
            AnnotatedClass classInfo)
    {
        super(containerType, valueDeser, valueTypeDeser, valueInstantiator, delegateDeser,
                nuller, unwrapSingle, classInfo);
    }

    /**
     * Copy-constructor that can be used by sub-classes to allow
     * copy-on-write styling copying of settings of an existing instance.
     */
    protected ArrayBlockingQueueDeserializer(ArrayBlockingQueueDeserializer src) {
        super(src);
    }

    /**
     * Fluent-factory method call to construct contextual instance.
     */
    @Override
    @SuppressWarnings("unchecked")
    protected ArrayBlockingQueueDeserializer withResolved(ValueDeserializer<?> dd,
            ValueDeserializer<?> vd, TypeDeserializer vtd,
            NullValueProvider nuller, Boolean unwrapSingle)
    {
        return new ArrayBlockingQueueDeserializer(_containerType,
                (ValueDeserializer<Object>) vd, vtd,
                _valueInstantiator, (ValueDeserializer<Object>) dd,
                nuller, unwrapSingle,
                _classInfo);
    }

    /*
    /**********************************************************************
    /* ValueDeserializer API
    /**********************************************************************
     */

    @Override
    protected Collection<Object> createDefaultInstance(DeserializationContext ctxt)
        throws JacksonException
    {
        // 07-Nov-2016, tatu: Important: cannot create using default ctor (one
        //    does not exist); and also need to know exact size. Hence, return
        //    null from here
        return null;
    }

    @Override
    protected Collection<Object> _deserializeFromArray(JsonParser p, DeserializationContext ctxt,
            Collection<Object> result0)
        throws JacksonException
    {
        if (result0 == null) { // usual case
            result0 = new ArrayList<>();
        }
        result0 = super._deserializeFromArray(p, ctxt, result0);
        if (result0.isEmpty()) {
            return new ArrayBlockingQueue<>(1, false);
        }
        return new ArrayBlockingQueue<>(result0.size(), false, result0);
    }

    @Override
    public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer)
        throws JacksonException
    {
        // In future could check current token... for now this should be enough:
        return typeDeserializer.deserializeTypedFromArray(p, ctxt);
    }
}
