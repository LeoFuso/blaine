package tools.jackson.databind.jsontype.impl;

import com.fasterxml.jackson.annotation.JsonTypeInfo.As;

import tools.jackson.databind.BeanProperty;
import tools.jackson.databind.SerializationContext;
import tools.jackson.databind.jsontype.TypeIdResolver;

/**
 * Type serializer used with {@link As#EXISTING_PROPERTY} inclusion mechanism.
 * Expects type information to be a well-defined property on all sub-classes.
 * Inclusion of type information otherwise follows behavior of {@link As#PROPERTY}.
 */
public class AsExistingPropertyTypeSerializer
    extends TypeSerializerBase
{
    protected final String _typePropertyName;

    /** @since 3.2 */
    public AsExistingPropertyTypeSerializer(TypeIdResolver idRes,
            BeanProperty property, String propName,
            Class<?> skipTypeIdFor)
    {
        super(idRes, property, skipTypeIdFor);
        _typePropertyName = propName;
    }

    @Override
    public AsExistingPropertyTypeSerializer forProperty(SerializationContext ctxt,
            BeanProperty prop) {
        return (_property == prop) ? this :
            new AsExistingPropertyTypeSerializer(_idResolver, prop, _typePropertyName,
                    _skipTypeIdFor);
    }

    @Override
    public As getTypeInclusion() { return As.EXISTING_PROPERTY; }
}
