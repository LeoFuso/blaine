package tools.jackson.databind.jsontype.impl;

import com.fasterxml.jackson.annotation.JsonTypeInfo.As;

import tools.jackson.databind.BeanProperty;
import tools.jackson.databind.SerializationContext;
import tools.jackson.databind.jsontype.TypeIdResolver;

/**
 * Type serializer that preferably embeds type information as an additional
 * JSON Object property, if possible (when resulting serialization would
 * use JSON Object). If this is not possible (for JSON Arrays, scalars),
 * uses a JSON Array wrapper (similar to how
 * {@link As#WRAPPER_ARRAY} always works) as a fallback.
 */
public class AsPropertyTypeSerializer
    extends TypeSerializerBase
{
    protected final String _typePropertyName;

    /** @since 3.2 */
    public AsPropertyTypeSerializer(TypeIdResolver idRes, BeanProperty property, String propName,
            Class<?> skipTypeIdFor)
    {
        super(idRes, property, skipTypeIdFor);
        _typePropertyName = propName;
    }

    @Override
    public AsPropertyTypeSerializer forProperty(SerializationContext ctxt,
            BeanProperty prop) {
        return (_property == prop) ? this :
            new AsPropertyTypeSerializer(_idResolver, prop, _typePropertyName,
                    _skipTypeIdFor);
    }

    @Override
    public String getPropertyName() { return _typePropertyName; }

    @Override
    public As getTypeInclusion() { return As.PROPERTY; }
}
