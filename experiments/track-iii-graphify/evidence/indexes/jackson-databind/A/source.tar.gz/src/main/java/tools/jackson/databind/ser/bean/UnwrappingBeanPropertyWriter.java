package tools.jackson.databind.ser.bean;

import java.util.Map.Entry;

import tools.jackson.core.JsonGenerator;
import tools.jackson.core.io.SerializedString;
import tools.jackson.databind.JavaType;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.SerializationContext;
import tools.jackson.databind.ValueSerializer;
import tools.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
import tools.jackson.databind.jsonFormatVisitors.JsonObjectFormatVisitor;
import tools.jackson.databind.node.ObjectNode;
import tools.jackson.databind.ser.BeanPropertyWriter;
import tools.jackson.databind.ser.impl.PropertySerializerMap;
import tools.jackson.databind.util.NameTransformer;

/**
 * Variant of {@link BeanPropertyWriter} which will handle unwrapping
 * of JSON Object (including of properties of Object within surrounding
 * JSON object, and not as sub-object).
 */
public class UnwrappingBeanPropertyWriter
    extends BeanPropertyWriter
{
    /**
     * Transformer used to add prefix and/or suffix for properties
     * of unwrapped POJO.
     */
    protected final NameTransformer _nameTransformer;

    /*
    /**********************************************************************
    /* Life-cycle
    /**********************************************************************
     */

    public UnwrappingBeanPropertyWriter(BeanPropertyWriter base, NameTransformer unwrapper) {
        super(base);
        _nameTransformer = unwrapper;
    }

    protected UnwrappingBeanPropertyWriter(UnwrappingBeanPropertyWriter base, NameTransformer transformer,
            SerializedString name) {
        super(base, name);
        _nameTransformer = transformer;
    }

    @Override
    public UnwrappingBeanPropertyWriter rename(NameTransformer transformer)
    {
        String oldName = _name.getValue();
        String newName = transformer.transform(oldName);

        // important: combine transformers:
        transformer = NameTransformer.chainedTransformer(transformer, _nameTransformer);

        return _new(transformer, new SerializedString(newName));
    }

    /**
     * Overridable factory method used by sub-classes
     */
    protected UnwrappingBeanPropertyWriter _new(NameTransformer transformer, SerializedString newName)
    {
        return new UnwrappingBeanPropertyWriter(this, transformer, newName);
    }

    /*
    /**********************************************************************
    /* Overrides, public methods
    /**********************************************************************
     */

    @Override
    public boolean isUnwrapping() {
        return true;
    }

    @Override
    public void serializeAsProperty(Object bean, JsonGenerator gen, SerializationContext prov)
        throws Exception
    {
        final Object value = get(bean);
        if (value == null) {
            // Hmmh. I assume we MUST pretty much suppress nulls, since we
            // can't really unwrap them...
            return;
        }
        ValueSerializer<Object> ser = _serializer;
        if (ser == null) {
            Class<?> cls = value.getClass();
            PropertySerializerMap map = _dynamicSerializers;
            ser = map.serializerFor(cls);
            if (ser == null) {
                ser = _findAndAddDynamic(map, cls, prov);
            }
        }
        if (_suppressableValue != null) {
            if (MARKER_FOR_EMPTY == _suppressableValue) {
                if (ser.isEmpty(prov, value)) {
                    return;
                }
            } else if (_suppressableValue.equals(value)) {
                return;
            }
        }
        // For non-nulls, first: simple check for direct cycles
        if (value == bean) {
            if (_handleSelfReference(bean, gen, prov, ser)) {
                return;
            }
        }

        // note: must verify we are using unwrapping serializer; if not, will write field name
        if (!ser.isUnwrappingSerializer()) {
            gen.writeName(_name);
        }

        if (_typeSerializer == null) {
            ser.serialize(value, gen, prov);
        } else {
            ser.serializeWithType(value, gen, prov, _typeSerializer);
        }
    }

    // need to override as we must get unwrapping instance...
    @Override
    public void assignSerializer(ValueSerializer<Object> ser)
    {
        if (ser != null) {
            ser = _asUnwrapping(ser);
        }
        super.assignSerializer(ser);
    }

    /**
     * Resolves the effective unwrapping serializer for this property, constructing it
     * on demand if {@link #assignSerializer} was not called (which happens when the
     * declared type is non-final, since {@code resolve} defers to dynamic resolution).
     * Used for [databind#2883] conflict detection.
     *
     * @since 3.2
     */
    public ValueSerializer<Object> findUnwrappingSerializer(SerializationContext ctxt)
    {
        ValueSerializer<Object> ser = getSerializer();
        if (ser != null) {
            return ser;
        }
        ser = ctxt.findPrimaryPropertySerializer(getType(), this);
        return (ser == null) ? null : _asUnwrapping(ser);
    }

    // @since 3.2
    private ValueSerializer<Object> _asUnwrapping(ValueSerializer<Object> ser)
    {
        NameTransformer t = _nameTransformer;
        if (ser.isUnwrappingSerializer()
                // as per [databind#2060], need to also check this, in case someone writes
                // custom implementation that does not extend standard implementation:
                && ser instanceof UnwrappingBeanSerializer unwrappingBeanSerializer) {
            t = NameTransformer.chainedTransformer(t, unwrappingBeanSerializer._nameTransformer);
        }
        return ser.unwrappingSerializer(t);
    }

    /*
    /**********************************************************************
    /* Overrides: schema generation
    /**********************************************************************
     */

    @Override
    public void depositSchemaProperty(final JsonObjectFormatVisitor visitor,
            SerializationContext ctxt)
    {
        ValueSerializer<Object> ser = ctxt
                .findPrimaryPropertySerializer(getType(), this)
                .unwrappingSerializer(_nameTransformer);

        if (ser.isUnwrappingSerializer()) {
            ser.acceptJsonFormatVisitor(new JsonFormatVisitorWrapper.Base(ctxt) {
                // an unwrapping serializer will always expect ObjectFormat,
                // hence, the other cases do not have to be implemented
                @Override
                public JsonObjectFormatVisitor expectObjectFormat(JavaType type) {
                    return visitor;
                }
            }, getType());
        } else {
            super.depositSchemaProperty(visitor, ctxt);
        }
    }

    // Override needed to support legacy JSON Schema generator
    @Override
    protected void _depositSchemaProperty(ObjectNode propertiesNode, JsonNode schemaNode)
    {
        JsonNode props = schemaNode.get("properties");
        if (props != null) {
            for (Entry<String,JsonNode> entry : props.properties()) {
                String name = entry.getKey();
                if (_nameTransformer != null) {
                    name = _nameTransformer.transform(name);
                }
                propertiesNode.set(name, entry.getValue());
            }
        }
    }

    /*
    /**********************************************************************
    /* Overrides: internal, other
    /**********************************************************************
     */

    // need to override as we must get unwrapping instance...
    @Override
    protected ValueSerializer<Object> _findAndAddDynamic(PropertySerializerMap map,
            Class<?> type, SerializationContext ctxt)
    {
        ValueSerializer<Object> serializer;
        if (_nonTrivialBaseType != null) {
            JavaType subtype = ctxt.constructSpecializedType(_nonTrivialBaseType, type);
            serializer = ctxt.findPrimaryPropertySerializer(subtype, this);
        } else {
            serializer = ctxt.findPrimaryPropertySerializer(type, this);
        }
        NameTransformer t = _nameTransformer;
        if (serializer.isUnwrappingSerializer()
            // as per [databind#2060], need to also check this, in case someone writes
            // custom implementation that does not extend standard implementation:
            && serializer instanceof UnwrappingBeanSerializer unwrappingBeanSerializer) {
                t = NameTransformer.chainedTransformer(t, unwrappingBeanSerializer._nameTransformer);
        }
        serializer = serializer.unwrappingSerializer(t);

        _dynamicSerializers = _dynamicSerializers.newWith(type, serializer);
        return serializer;
    }
}
