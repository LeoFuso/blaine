/*
 * Copyright 2025-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.kafka.config;

import java.util.Arrays;
import java.util.Collection;
import java.util.regex.Pattern;

import org.jspecify.annotations.Nullable;

import org.springframework.beans.BeanUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.kafka.core.ShareConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.ShareConsumerRecordRecoverer;
import org.springframework.kafka.listener.ShareKafkaMessageListenerContainer;
import org.springframework.kafka.support.JavaUtils;
import org.springframework.kafka.support.TopicPartitionOffset;
import org.springframework.kafka.support.converter.RecordMessageConverter;
import org.springframework.util.Assert;

/**
 * A {@link KafkaListenerContainerFactory} implementation to create {@link ShareKafkaMessageListenerContainer}
 * instances for Kafka's share consumer model.
 * <p>
 * This factory provides common configuration and lifecycle management for share consumer containers.
 * It handles the creation of containers based on endpoints, topics, or patterns, and applies common
 * configuration properties to the created containers.
 * <p>
 * The share consumer model enables cooperative rebalancing, allowing consumers to maintain ownership of
 * some partitions while relinquishing others during rebalances, which can reduce disruption compared to
 * the classic consumer model.
 *
 * @param <K> the key type
 * @param <V> the value type
 *
 * @author Soby Chacko
 * @author Kumar Gaurav
 * @author Sudhanshu Ratna Thakur
 *
 * @since 4.0
 */
public class ShareKafkaListenerContainerFactory<K, V>
		implements KafkaListenerContainerFactory<ShareKafkaMessageListenerContainer<K, V>>,
		ApplicationEventPublisherAware, ApplicationContextAware {

	private final ShareConsumerFactory<? super K, ? super V> shareConsumerFactory;

	private final ContainerProperties containerProperties = new ContainerProperties((Pattern) null);

	private boolean autoStartup = true;

	private int phase = 0;

	private int concurrency = 1;

	private @Nullable ShareConsumerRecordRecoverer recordRecoverer;

	private @Nullable RecordMessageConverter recordMessageConverter;

	@SuppressWarnings("NullAway.Init")
	private ApplicationEventPublisher applicationEventPublisher;

	@SuppressWarnings("NullAway.Init")
	private ApplicationContext applicationContext;

	/**
	 * Construct an instance with the provided consumer factory.
	 * @param shareConsumerFactory the share consumer factory
	 */
	public ShareKafkaListenerContainerFactory(ShareConsumerFactory<K, V> shareConsumerFactory) {
		this.shareConsumerFactory = shareConsumerFactory;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	/**
	 * Set whether containers created by this factory should auto-start.
	 * @param autoStartup true to auto-start
	 */
	public void setAutoStartup(boolean autoStartup) {
		this.autoStartup = autoStartup;
	}

	/**
	 * Set the phase in which containers created by this factory should start and stop.
	 * @param phase the phase
	 */
	public void setPhase(int phase) {
		this.phase = phase;
	}

	/**
	 * Set the concurrency for containers created by this factory.
	 * <p>
	 * This specifies the number of consumer threads to create within each container.
	 * Each thread creates its own {@link org.apache.kafka.clients.consumer.ShareConsumer}
	 * instance and participates in the same share group. The Kafka broker distributes
	 * records across all consumer instances, providing record-level load balancing.
	 * <p>
	 * This can be overridden per listener endpoint using the {@code concurrency}
	 * attribute on {@code @KafkaListener}.
	 * @param concurrency the number of consumer threads (must be greater than 0)
	 */
	public void setConcurrency(int concurrency) {
		this.concurrency = concurrency;
	}

	/**
	 * Set a {@link ShareConsumerRecordRecoverer} to use for all containers created
	 * by this factory. If not set, the container's default
	 * ({@link org.springframework.kafka.listener.ShareConsumerRecordRecoverer#REJECTING}) is used.
	 * @param recordRecoverer the recoverer
	 * @since 4.1
	 */
	public void setShareConsumerRecordRecoverer(ShareConsumerRecordRecoverer recordRecoverer) {
		this.recordRecoverer = recordRecoverer;
	}

	/**
	 * Set the message converter to use if dynamic argument type matching is needed for
	 * record listeners.
	 * @param recordMessageConverter the converter.
	 * @since 4.2
	 */
	public void setRecordMessageConverter(RecordMessageConverter recordMessageConverter) {
		this.recordMessageConverter = recordMessageConverter;
	}

	/**
	 * Obtain the factory-level container properties - set properties as needed
	 * and they will be copied to each listener container instance created by this factory.
	 * @return the properties.
	 */
	public ContainerProperties getContainerProperties() {
		return this.containerProperties;
	}

	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		this.applicationEventPublisher = applicationEventPublisher;
	}

	@Override
	@SuppressWarnings({"unchecked", "rawtypes"})
	public ShareKafkaMessageListenerContainer<K, V> createListenerContainer(KafkaListenerEndpoint endpoint) {
		ShareKafkaMessageListenerContainer<K, V> instance = createContainerInstance(endpoint);
		JavaUtils.INSTANCE
				.acceptIfNotNull(endpoint.getId(), instance::setBeanName);
		if (endpoint instanceof AbstractKafkaListenerEndpoint abstractKafkaListenerEndpoint) {
			configureEndpoint(abstractKafkaListenerEndpoint);
		}
		endpoint.setupListenerContainer(instance, this.recordMessageConverter);
		initializeContainer(instance, endpoint);
		return instance;
	}

	private void configureEndpoint(AbstractKafkaListenerEndpoint<K, V> endpoint) {
		// Minimal configuration; can add more properties later
	}

	/**
	 * Initialize the provided container with common configuration properties.
	 * @param instance the container instance
	 * @param endpoint the endpoint
	 */
	protected void initializeContainer(ShareKafkaMessageListenerContainer<K, V> instance, KafkaListenerEndpoint endpoint) {
		ContainerProperties properties = instance.getContainerProperties();
		boolean effectiveAutoStartup = endpoint.getAutoStartup() != null ? endpoint.getAutoStartup() : this.autoStartup;

		// Validate share group configuration
		validateShareConfiguration(endpoint);

		// Copy factory-level properties to container
		BeanUtils.copyProperties(this.containerProperties, properties, "topics", "topicPartitions", "topicPattern",
				"messageListener", "ackCount", "ackTime", "subBatchPerPartition", "kafkaConsumerProperties");

		// Set concurrency - endpoint setting takes precedence over factory setting
		Integer conc = endpoint.getConcurrency();
		if (conc != null) {
			instance.setConcurrency(conc);
		}
		else {
			instance.setConcurrency(this.concurrency);
		}

		instance.setAutoStartup(effectiveAutoStartup);
		instance.setPhase(this.phase);
		instance.setApplicationContext(this.applicationContext);
		instance.setApplicationEventPublisher(this.applicationEventPublisher);

		JavaUtils.INSTANCE
				.acceptIfNotNull(this.recordRecoverer, instance::setShareConsumerRecordRecoverer)
				.acceptIfNotNull(endpoint.getGroupId(), properties::setGroupId)
				.acceptIfNotNull(endpoint.getClientIdPrefix(), properties::setClientId);
	}

	private static void validateShareConfiguration(KafkaListenerEndpoint endpoint) {
		// Validate that batch listeners aren't used with share consumers
		if (Boolean.TRUE.equals(endpoint.getBatchListener())) {
			throw new IllegalArgumentException(
					"Batch listeners are not supported with share consumers. " +
							"Share groups operate at the record level.");
		}

	}

	@Override
	public ShareKafkaMessageListenerContainer<K, V> createContainer(TopicPartitionOffset... topicPartitions) {
		throw new UnsupportedOperationException("ShareConsumer does not support explicit partition assignment");
	}

	@Override
	public ShareKafkaMessageListenerContainer<K, V> createContainer(String... topics) {
		KafkaListenerEndpoint endpoint = new KafkaListenerEndpointAdapter() {

			@Override
			public Collection<String> getTopics() {
				return Arrays.asList(topics);
			}
		};
		ShareKafkaMessageListenerContainer<K, V> instance = createContainerInstance(endpoint);
		initializeContainer(instance, endpoint);
		return instance;
	}

	@Override
	public ShareKafkaMessageListenerContainer<K, V> createContainer(Pattern topicPattern) {
		throw new UnsupportedOperationException("ShareConsumer does not support topic patterns");
	}

	/**
	 * Create a container instance for the provided endpoint.
	 * @param endpoint the endpoint
	 * @return the container instance
	 */
	protected ShareKafkaMessageListenerContainer<K, V> createContainerInstance(KafkaListenerEndpoint endpoint) {
		Collection<String> topics = endpoint.getTopics();
		Assert.state(topics != null, "'topics' must not be null");
		return new ShareKafkaMessageListenerContainer<>(this.shareConsumerFactory,
				new ContainerProperties(topics.toArray(new String[0])));
	}

}
