/*
 * Copyright 2023-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.kafka.listener.adapter;

/**
 * Message handler adapter implementing this interface can detect {@link HandlerAdapter} async return types.
 *
 * @author Wang zhiyang
 *
 * @since 3.2
 */
public interface AsyncRepliesAware {

	/**
	 * Return true if the {@link HandlerAdapter} return type is async.
	 * @return true for async replies.
	 * @since 3.2
	 */
	default boolean isAsyncReplies() {
		return false;
	}

}
