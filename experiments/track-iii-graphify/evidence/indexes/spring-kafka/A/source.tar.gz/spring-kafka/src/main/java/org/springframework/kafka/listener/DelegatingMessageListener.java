/*
 * Copyright 2017-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.kafka.listener;

import org.springframework.kafka.listener.adapter.AsyncRepliesAware;

/**
 * Classes implementing this interface allow containers to determine the type of the
 * ultimate listener.
 * <p>
 * This interface also implements {@link AsyncRepliesAware} contract delegating to the {@link #getDelegate()},
 * respectivelly.
 *
 * @param <T> the type received by the listener.
 *
 * @author Gary Russell
 * @author Artem Bilan
 *
 * @since 2.0
 *
 */
public interface DelegatingMessageListener<T> extends AsyncRepliesAware {

	/**
	 * Return the delegate.
	 * @return the delegate.
	 */
	T getDelegate();

	@Override
	default boolean isAsyncReplies() {
		return getDelegate() instanceof AsyncRepliesAware asyncRepliesAware && asyncRepliesAware.isAsyncReplies();
	}

}
